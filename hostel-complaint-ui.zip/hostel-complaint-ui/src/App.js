import React, { useEffect, useState } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { UserProvider } from './UserContext';
import SplashScreen from './components/SplashScreen';
import StudentRegistration from './components/student/StudentRegistration';
import StudentLogin from './components/student/StudentLogin';
import StudentDashboard from './components/student/StudentDashboard';
import SubmitComplaint from './components/student/SubmitComplaint';
import ComplaintHistory from './components/student/ComplaintHistory';
import NotificationCenter from './components/student/NotificationCenter';
import WardenLogin from './components/warden/WardenLogin';
import WardenDashboard from './components/warden/WardenDashboard';
import InspectionScheduling from './components/warden/InspectionScheduling';
import AdminLogin from './components/admin/AdminLogin';
import AdminPanel from './components/admin/AdminPanel';
import RoleSelection from './components/RoleSelection';
import './App.css';
import RoomInfo from './components/student/RoomInfo';
import HostelRules from './components/student/HostelRules';
import LeaveApplication from './components/student/LeaveApplication';
import FeeStatus from './components/student/FeeStatus';
import WardenRoomManagement from './components/warden/WardenRoomManagement';
import RoomChangeRequest from './components/student/RoomChangeRequest';
import ApplicationHistory from './components/student/ApplicationHistory';
import LeavingHostel from './components/student/LeavingHostel';
import WardenLeavingHostel from './components/warden/WardenLeavingHostel';
import WardenLeaveApprovals from './components/warden/WardenLeaveApprovals';
import WardenRoomChangeApprovals from './components/warden/WardenRoomChangeApprovals';
import WardenStudentList from './components/warden/WardenStudentList';
import WardenFeeStatus from './components/warden/WardenFeeStatus';
import WardenNotificationCenter from './components/warden/WardenNotificationCenter';
import AdminStudentManagement from './components/admin/AdminStudentManagement';
import AdminWardenManagement from './components/admin/AdminWardenManagement';
import AdminLeavingRemovals from './components/admin/AdminLeavingRemovals';
import ChangePassword from './components/student/ChangePassword';
import WardenChangePassword from './components/warden/ChangePassword';
import AllStudentsList from './components/admin/AllStudentsList';
import AllWardensList from './components/admin/AllWardensList';
import AdminSendMessage from './components/admin/AdminSendMessage';
import WardenSendMessage from './components/warden/WardenSendMessage';
import AdminSendMessageToWardens from './components/admin/AdminSendMessageToWardens';
import WardenComplaints from './components/warden/WardenComplaints';

function App() {
  const [showSplash, setShowSplash] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setShowSplash(false);
    }, 2500); // 2.5 seconds
    return () => clearTimeout(timer);
  }, []);

  if (showSplash) {
    return <SplashScreen />;
  }

  return (
    <UserProvider>
      <Router>
        <Routes>
          {/* Public routes */}
          <Route path="/" element={<RoleSelection />} />
          
          {/* Student routes */}
          <Route path="/student/register" element={<StudentRegistration />} />
          <Route path="/student/login" element={<StudentLogin />} />
          <Route path="/student/dashboard" element={<StudentDashboard />} />
          <Route path="/student/submit-complaint" element={<SubmitComplaint />} />
          <Route path="/student/complaint-history" element={<ComplaintHistory />} />
          <Route path="/student/notifications" element={<NotificationCenter />} />
          <Route path="/student/room-info" element={<RoomInfo />} />
          <Route path="/student/hostel-rules" element={<HostelRules />} />
          <Route path="/student/leave-application" element={<LeaveApplication />} />
          <Route path="/student/fee-status" element={<FeeStatus />} />
          <Route path="/student/room-change-request" element={<RoomChangeRequest />} />
          <Route path="/student/application-history" element={<ApplicationHistory />} />
          <Route path="/student/leaving-hostel" element={<LeavingHostel />} />
          <Route path="/student/change-password" element={<ChangePassword />} />
          
          {/* Warden routes */}
          <Route path="/warden/login" element={<WardenLogin />} />
          <Route path="/warden/dashboard" element={<WardenDashboard />} />
          <Route path="/warden/inspections" element={<InspectionScheduling />} />
          <Route path="/warden/room-management" element={<WardenRoomManagement />} />
          <Route path="/warden/leaving-hostel-approvals" element={<WardenLeavingHostel />} />
          <Route path="/warden/leave-approvals" element={<WardenLeaveApprovals />} />
          <Route path="/warden/room-change-approvals" element={<WardenRoomChangeApprovals />} />
          <Route path="/warden/student-list" element={<WardenStudentList />} />
          <Route path="/warden/fee-status" element={<WardenFeeStatus />} />
          <Route path="/warden/notifications" element={<WardenNotificationCenter />} />
          <Route path="/warden/change-password" element={<WardenChangePassword />} />
          <Route path="/warden/send-message" element={<WardenSendMessage />} />
          <Route path="/warden/complaints" element={<WardenComplaints />} />
          
          {/* Admin routes */}
          <Route path="/admin/login" element={<AdminLogin />} />
          <Route path="/admin/dashboard" element={<AdminPanel />} />
          <Route path="/admin/students" element={<AdminStudentManagement />} />
          <Route path="/admin/wardens" element={<AdminWardenManagement />} />
          <Route path="/admin/leaving-removals" element={<AdminLeavingRemovals />} />
          <Route path="/admin/all-students-list" element={<AllStudentsList />} />
          <Route path="/admin/all-wardens-list" element={<AllWardensList />} />
          <Route path="/admin/send-message" element={<AdminSendMessage />} />
          <Route path="/admin/send-message-wardens" element={<AdminSendMessageToWardens />} />
          
          {/* Legacy routes for backward compatibility */}
          <Route path="/register" element={<StudentRegistration />} />
          <Route path="/login" element={<StudentLogin />} />
          <Route path="/dashboard" element={<StudentDashboard />} />
          <Route path="/submit-complaint" element={<SubmitComplaint />} />
          <Route path="/complaint-history" element={<ComplaintHistory />} />
          <Route path="/warden-login" element={<WardenLogin />} />
          <Route path="/warden-dashboard" element={<WardenDashboard />} />
          <Route path="/inspection-scheduling" element={<InspectionScheduling />} />
          <Route path="/admin-login" element={<AdminLogin />} />
          <Route path="/admin/panel" element={<AdminPanel />} />
          <Route path="/notifications" element={<NotificationCenter />} />
        </Routes>
      </Router>
    </UserProvider>
  );
}

export default App;
