import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { FiArrowLeft, FiUser, FiMenu } from 'react-icons/fi';
import ProfileDrawer from './ProfileDrawer';
import Sidebar from './Sidebar';
import './CommonHeader.css';
import { useUser } from '../UserContext';

const CommonHeader = ({ title, showBackButton = true, userRole, showMenu = false }) => {
  const navigate = useNavigate();
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const { user, updateUser, clearUser } = useUser();

  const handleBackClick = () => {
    navigate(-1);
  };

  const handleProfileClick = () => {
    setIsProfileOpen(true);
  };

  const handleCloseProfile = () => {
    setIsProfileOpen(false);
  };

  const handleMenuClick = () => {
    setIsSidebarOpen(true);
  };

  const handleCloseSidebar = () => {
    setIsSidebarOpen(false);
  };

  return (
    <>
      <header className="app-header">
        <div className="header-content">
          <div className="header-left">
            {showBackButton && (
              <button className="header-button back-button" onClick={handleBackClick}>
                <FiArrowLeft />
              </button>
            )}
            {showMenu && (
              <button className="header-button menu-button" onClick={handleMenuClick}>
                <FiMenu />
              </button>
            )}
          </div>
          
          <h1 className="header-title">{title}</h1>
          
          <div className="header-right">
            {user && user.name && (
              <button className="header-button profile-button" onClick={handleProfileClick}>
                <FiUser />
              </button>
            )}
          </div>
        </div>
      </header>
      
      {user && user.name && (
        <ProfileDrawer isOpen={isProfileOpen} onClose={handleCloseProfile} user={user} updateUser={updateUser} clearUser={clearUser} />
      )}
      <Sidebar isOpen={isSidebarOpen} onClose={handleCloseSidebar} userRole={userRole} />
    </>
  );
};

export default CommonHeader; 