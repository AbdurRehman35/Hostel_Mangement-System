import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import CommonHeader from '../CommonHeader';
import './WardenLogin.css';
import { useUser } from '../../UserContext';
import { getWardenByEmail } from '../student/usersData';

const WardenLogin = () => {
  const navigate = useNavigate();
  const { updateUser } = useUser();

  const handleSubmit = (e) => {
    e.preventDefault();
    const name = e.target[0].value;
    const email = e.target[1].value;
    const block = e.target[2].value;
    const password = e.target[3].value;
    const warden = getWardenByEmail(email);
    if (!warden) {
      alert('No warden found with this email.');
      return;
    }
    if (warden.password !== password) {
      alert('Incorrect password.');
      return;
    }
    updateUser({ name, email: warden.email, role: 'Warden', block });
    alert('Login successful!');
    navigate('/warden/dashboard');
  };

  return (
    <div className="warden-login-container">
      <CommonHeader 
        title="Warden Login"
        userRole="warden"
        showMenu={false}
        showBackButton={true}
      />
      <div className="warden-login-content">
        <form className="warden-login-form" onSubmit={handleSubmit}>
          <h2 className="warden-login-title">Warden Login</h2>
          <input type="text" placeholder="Name" className="warden-login-input" required />
          <input type="email" placeholder="Email" className="warden-login-input" required />
          <input type="text" placeholder="Block" className="warden-login-input" required />
          <input type="password" placeholder="Password" className="warden-login-input" required />
          <button type="submit" className="warden-login-btn">Login</button>
          <p className="warden-login-link">Admin? <Link to="/admin-login">Login here</Link></p>
          <p className="warden-login-link"><Link to="/warden/change-password">Change Password</Link> | <Link to="/warden/change-password">Forgot Password?</Link></p>
        </form>
      </div>
    </div>
  );
};

export default WardenLogin; 