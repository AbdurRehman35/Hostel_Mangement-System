import React, { useState } from 'react';
import CommonHeader from '../CommonHeader';
import { getWardenByEmail, updateWardenPassword } from '../student/usersData';

const ChangePassword = () => {
  const [email, setEmail] = useState('');
  const [oldPassword, setOldPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = e => {
    e.preventDefault();
    const warden = getWardenByEmail(email);
    if (!warden) {
      setError('No warden found with this email.');
      setSuccess(false);
      return;
    }
    if (warden.password !== oldPassword) {
      setError('Old password is incorrect.');
      setSuccess(false);
      return;
    }
    updateWardenPassword(email, newPassword);
    setSuccess(true);
    setError('');
    setEmail('');
    setOldPassword('');
    setNewPassword('');
  };

  return (
    <div className="login-container">
      <CommonHeader title="Change Password" userRole="warden" showMenu={false} showBackButton={true} />
      <div className="login-content">
        <form className="login-form" onSubmit={handleSubmit}>
          <h2 className="login-title">Change Password</h2>
          {success && <div className="complaint-success">Password changed successfully!</div>}
          {error && <div className="complaint-success" style={{background:'#ffeaea', color:'#e53e3e'}}>{error}</div>}
          <input type="email" placeholder="Email" className="login-input" value={email} onChange={e => setEmail(e.target.value)} required />
          <input type="password" placeholder="Old Password" className="login-input" value={oldPassword} onChange={e => setOldPassword(e.target.value)} required />
          <input type="password" placeholder="New Password" className="login-input" value={newPassword} onChange={e => setNewPassword(e.target.value)} required />
          <button type="submit" className="login-btn">Change Password</button>
        </form>
      </div>
    </div>
  );
};

export default ChangePassword; 