import React from 'react';
import CommonHeader from '../CommonHeader';
import './InspectionScheduling.css';

const InspectionScheduling = () => {
  // Dummy data for demonstration
  const inspections = [
    { id: 1, room: 'A101', date: '2024-05-10', status: 'Scheduled' },
    { id: 2, room: 'B202', date: '2024-05-12', status: 'Completed' },
    { id: 3, room: 'C303', date: '2024-05-15', status: 'Scheduled' },
  ];

  return (
    <div className="inspection-scheduling-container">
      <CommonHeader 
        title="Inspection Scheduling" 
        userRole="warden"
        showMenu={true}
      />
      <main className="inspection-scheduling-main">
        <div className="inspection-scheduling-content">
          <h1 className="inspection-scheduling-title">Room Inspections</h1>
          <div className="inspection-list">
            {inspections.map((inspection) => (
              <div className="inspection-card" key={inspection.id}>
                <div className="inspection-room">Room: {inspection.room}</div>
                <div className="inspection-date">Date: {inspection.date}</div>
                <div className={`inspection-status status-${inspection.status.replace(/\s/g, '').toLowerCase()}`}>{inspection.status}</div>
              </div>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
};

export default InspectionScheduling; 