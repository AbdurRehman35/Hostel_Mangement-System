import React, { useEffect, useState } from 'react';
import CommonHeader from '../CommonHeader';
import { getComplaints, resolveComplaint } from '../complaintsData';
import { getAllStudents, getWardenByEmail } from '../student/usersData';
import { useUser } from '../../UserContext';

const WardenComplaints = () => {
  const { user } = useUser();
  const [complaints, setComplaints] = useState([]);
  const [students, setStudents] = useState([]);

  useEffect(() => {
    setStudents(getAllStudents());
  }, []);

  useEffect(() => {
    if (!user || !user.email) return;
    const warden = getWardenByEmail(user.email);
    if (!warden || !warden.block) return;
    const blockStudents = getAllStudents().filter(s => (s.floor || '').toLowerCase() === warden.block.toLowerCase());
    const blockComplaints = getComplaints().filter(c => blockStudents.some(s => s.name === c.student));
    setComplaints(blockComplaints);
  }, [user]);

  const handleResolve = (id) => {
    resolveComplaint(id);
    if (!user || !user.email) return;
    const warden = getWardenByEmail(user.email);
    if (!warden || !warden.block) return;
    const blockStudents = getAllStudents().filter(s => (s.floor || '').toLowerCase() === warden.block.toLowerCase());
    const blockComplaints = getComplaints().filter(c => blockStudents.some(s => s.name === c.student));
    setComplaints(blockComplaints);
  };

  return (
    <div className="complaint-container">
      <CommonHeader title="Complaints List" userRole="warden" showMenu={true} showBackButton={true} />
      <div className="complaint-content-wrapper">
        <div className="complaint-content" style={{maxWidth: 800}}>
          <h2 style={{textAlign: 'center', color: '#185a9d', marginBottom: 18}}>Complaints in Your Block</h2>
          {complaints.length === 0 ? (
            <div style={{color: '#888', textAlign: 'center'}}>No complaints found for your block.</div>
          ) : (
            <table style={{width: '100%', borderCollapse: 'collapse', background: '#f8fafd', borderRadius: 10, overflow: 'hidden', boxShadow: '0 2px 8px rgba(67,206,162,0.08)'}}>
              <thead>
                <tr style={{background: '#43cea2', color: '#fff'}}>
                  <th style={{padding: '10px 12px'}}>Type</th>
                  <th style={{padding: '10px 12px'}}>Student</th>
                  <th style={{padding: '10px 12px'}}>Description</th>
                  <th style={{padding: '10px 12px'}}>Date</th>
                  <th style={{padding: '10px 12px'}}>Status</th>
                  <th style={{padding: '10px 12px'}}>Action</th>
                </tr>
              </thead>
              <tbody>
                {complaints.map((c) => (
                  <tr key={c.id}>
                    <td style={{padding: '10px 12px'}}>{c.type}</td>
                    <td style={{padding: '10px 12px'}}>{c.student}</td>
                    <td style={{padding: '10px 12px'}}>{c.description}</td>
                    <td style={{padding: '10px 12px'}}>{c.date}</td>
                    <td style={{padding: '10px 12px'}}>{c.status}</td>
                    <td style={{padding: '10px 12px'}}>
                      {c.status === 'Pending' && (
                        <button style={{background: '#1ca97a', color: '#fff', border: 'none', borderRadius: 6, padding: '6px 14px', fontWeight: 600, cursor: 'pointer'}} onClick={() => handleResolve(c.id)}>Resolve</button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
};

export default WardenComplaints; 