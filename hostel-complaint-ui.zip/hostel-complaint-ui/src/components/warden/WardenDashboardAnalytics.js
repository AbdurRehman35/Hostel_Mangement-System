import React, { useEffect, useState } from 'react';
import { getAllStudents, getWardenByEmail } from '../student/usersData';
import { getComplaints } from '../complaintsData';
import { useUser } from '../../UserContext';
import './WardenDashboard.css';

const WardenDashboardAnalytics = () => {
  const { user } = useUser();
  const [totalStudents, setTotalStudents] = useState(0);
  const [totalComplaints, setTotalComplaints] = useState(0);
  const [pendingComplaints, setPendingComplaints] = useState(0);
  const [approvedComplaints, setApprovedComplaints] = useState(0);
  const [rejectedComplaints, setRejectedComplaints] = useState(0);

  useEffect(() => {
    if (!user || !user.email) return;
    const warden = getWardenByEmail(user.email);
    if (!warden || !warden.block) return;
    const students = getAllStudents().filter(s => (s.floor || '').toLowerCase() === warden.block.toLowerCase());
    setTotalStudents(students.length);
    const complaints = getComplaints().filter(c => students.some(s => s.name === c.student));
    setTotalComplaints(complaints.length);
    setPendingComplaints(complaints.filter(c => c.status === 'Pending').length);
    setApprovedComplaints(complaints.filter(c => c.status === 'Resolved' || c.status === 'Approved').length);
    setRejectedComplaints(complaints.filter(c => c.status === 'Rejected').length);
  }, [user]);

  const warden = user ? getWardenByEmail(user.email) : null;
  if (!user || !warden || !warden.block) return null;

  return (
    <div className="warden-analytics-container">
      <div className="warden-analytics-card">
        <div className="warden-analytics-label">Total Students</div>
        <div className="warden-analytics-value">{totalStudents}</div>
      </div>
      <div className="warden-analytics-card">
        <div className="warden-analytics-label">Total Complaints</div>
        <div className="warden-analytics-value">{totalComplaints}</div>
      </div>
      <div className="warden-analytics-card">
        <div className="warden-analytics-label">Pending Complaints</div>
        <div className="warden-analytics-value">{pendingComplaints}</div>
      </div>
      <div className="warden-analytics-card">
        <div className="warden-analytics-label">Approved Complaints</div>
        <div className="warden-analytics-value">{approvedComplaints}</div>
      </div>
      <div className="warden-analytics-card">
        <div className="warden-analytics-label">Rejected Complaints</div>
        <div className="warden-analytics-value">{rejectedComplaints}</div>
      </div>
    </div>
  );
};

export default WardenDashboardAnalytics; 