import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import CommonHeader from '../CommonHeader';
import { getComplaints, resolveComplaint } from '../complaintsData';
import './WardenDashboard.css';
import WardenDashboardAnalytics from './WardenDashboardAnalytics';

const WardenDashboard = () => {
  const [complaints, setComplaints] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    setComplaints(getComplaints());
  }, []);

  // Remove handleRefresh and the Refresh button

  const handleResolve = (id) => {
    resolveComplaint(id);
    setComplaints(getComplaints());
  };

  return (
    <div className="warden-dashboard-container">
      <CommonHeader 
        title="Warden Dashboard" 
        userRole="warden"
        showMenu={true}
        showBackButton={false}
      />
      <main className="warden-dashboard-main">
        <div className="warden-dashboard-content">
          <WardenDashboardAnalytics />
          <h1 className="warden-dashboard-title">Warden Services</h1>
          <div className="warden-dashboard-stats">
            <div className="warden-dashboard-card" onClick={() => navigate('/warden/complaints')}>
              <div className="warden-card-icon">📋</div>
              <div className="warden-card-label">Complaints</div>
              <div className="warden-card-value">View and resolve student complaints</div>
            </div>
            <div className="warden-dashboard-card" onClick={() => navigate('/warden/room-management')}>
              <div className="warden-card-icon">🏠</div>
              <div className="warden-card-label">Room Management</div>
              <div className="warden-card-value">Add, edit, and assign rooms</div>
            </div>
            <div className="warden-dashboard-card" onClick={() => navigate('/warden/inspections')}>
              <div className="warden-card-icon">🕵️‍♂️</div>
              <div className="warden-card-label">Inspection Scheduling</div>
              <div className="warden-card-value">Schedule and view inspections</div>
            </div>
            <div className="warden-dashboard-card" onClick={() => navigate('/warden/leaving-hostel-approvals')}>
              <div className="warden-card-icon">🚪</div>
              <div className="warden-card-label">Leaving Hostel Approvals</div>
              <div className="warden-card-value">Approve or reject leaving hostel requests</div>
            </div>
            <div className="warden-dashboard-card" onClick={() => navigate('/warden/leave-approvals')}>
              <div className="warden-card-icon">🏖️</div>
              <div className="warden-card-label">Leave Applications</div>
              <div className="warden-card-value">Approve or reject leave requests</div>
            </div>
            <div className="warden-dashboard-card" onClick={() => navigate('/warden/room-change-approvals')}>
              <div className="warden-card-icon">🔄</div>
              <div className="warden-card-label">Room Change Requests</div>
              <div className="warden-card-value">Approve or reject room change requests</div>
            </div>
            <div className="warden-dashboard-card" onClick={() => navigate('/warden/student-list')}>
              <div className="warden-card-icon">👥</div>
              <div className="warden-card-label">Student List</div>
              <div className="warden-card-value">View all students and room info</div>
            </div>
            <div className="warden-dashboard-card" onClick={() => navigate('/warden/fee-status')}>
              <div className="warden-card-icon">💳</div>
              <div className="warden-card-label">Fee Status</div>
              <div className="warden-card-value">View and update all students' fee status</div>
            </div>
            <div className="warden-dashboard-card" onClick={() => navigate('/warden/notifications')}>
              <div className="warden-card-icon">🔔</div>
              <div className="warden-card-label">Notification Center</div>
              <div className="warden-card-value">Send notifications to students</div>
            </div>
            <div className="warden-dashboard-card" onClick={() => navigate('/warden/send-message')}>
              <div className="warden-card-icon">✉️</div>
              <div className="warden-card-label">Send Message</div>
              <div className="warden-card-value">Send message to all or specific wardens</div>
            </div>
          </div>

          {/* Remove the complaints section title and list entirely */}
        </div>
      </main>
    </div>
  );
};

export default WardenDashboard; 