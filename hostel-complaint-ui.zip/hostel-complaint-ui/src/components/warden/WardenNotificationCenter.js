import React, { useState, useEffect } from 'react';
import CommonHeader from '../CommonHeader';
import { getAllNotifications, addNotification, getAllStudents } from '../student/usersData';

const WardenNotificationCenter = () => {
  const [message, setMessage] = useState('');
  const [target, setTarget] = useState('all');
  const [notifications, setNotifications] = useState([]);
  const [students, setStudents] = useState([]);
  const [success, setSuccess] = useState(false);

  useEffect(() => {
    setStudents(getAllStudents());
    const all = getAllNotifications();
    // Flatten notifications for display
    let notifs = [];
    Object.entries(all).forEach(([email, arr]) => {
      arr.forEach(n => notifs.push({ ...n, target: email }));
    });
    setNotifications(notifs.sort((a, b) => b.id - a.id));
  }, []);

  const handleSend = e => {
    e.preventDefault();
    if (!message.trim()) return;
    addNotification(target, { id: Date.now(), message, date: new Date().toISOString().slice(0, 10) });
    setMessage('');
    setTarget('all');
    setSuccess(true);
    setTimeout(() => setSuccess(false), 2000);
    // Refresh notifications
    const all = getAllNotifications();
    let notifs = [];
    Object.entries(all).forEach(([email, arr]) => {
      arr.forEach(n => notifs.push({ ...n, target: email }));
    });
    setNotifications(notifs.sort((a, b) => b.id - a.id));
  };

  return (
    <div className="complaint-container">
      <CommonHeader title="Warden Notification Center" userRole="warden" showMenu={true} showBackButton={true} />
      <div className="complaint-content-wrapper">
        <div className="complaint-content" style={{maxWidth: 700}}>
          <h2 style={{textAlign: 'center', color: '#185a9d', marginBottom: 18}}>Send Notification</h2>
          {success && <div className="complaint-success">Notification sent!</div>}
          <form className="complaint-form" onSubmit={handleSend} style={{marginBottom: 32}}>
            <div className="form-group">
              <label className="form-label">Message *</label>
              <input type="text" className="form-input" value={message} onChange={e => setMessage(e.target.value)} required placeholder="Enter notification message" />
            </div>
            <div className="form-group">
              <label className="form-label">Send To</label>
              <select className="form-input" value={target} onChange={e => setTarget(e.target.value)}>
                <option value="all">All Hostellites</option>
                {students.map(s => <option key={s.email} value={s.email}>{s.name} ({s.email})</option>)}
              </select>
            </div>
            <button type="submit" className="submit-btn">Send Notification</button>
          </form>
          <h3 style={{textAlign: 'center', color: '#185a9d', marginBottom: 10}}>All Sent Notifications</h3>
          <table style={{width: '100%', borderCollapse: 'collapse', background: '#f8fafd', borderRadius: 10, overflow: 'hidden', boxShadow: '0 2px 8px rgba(67,206,162,0.08)'}}>
            <thead>
              <tr style={{background: '#43cea2', color: '#fff'}}>
                <th style={{padding: '10px 12px'}}>Message</th>
                <th style={{padding: '10px 12px'}}>Date</th>
                <th style={{padding: '10px 12px'}}>Target</th>
              </tr>
            </thead>
            <tbody>
              {notifications.length === 0 && (
                <tr><td colSpan={3} style={{textAlign: 'center', padding: 18, color: '#888'}}>No notifications sent yet.</td></tr>
              )}
              {notifications.map((n, i) => (
                <tr key={i}>
                  <td style={{padding: '10px 12px'}}>{n.message}</td>
                  <td style={{padding: '10px 12px'}}>{n.date}</td>
                  <td style={{padding: '10px 12px'}}>{n.target === 'all' ? 'All' : n.target}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default WardenNotificationCenter; 