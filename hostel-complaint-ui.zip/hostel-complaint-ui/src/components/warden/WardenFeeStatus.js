import React, { useEffect, useState } from 'react';
import CommonHeader from '../CommonHeader';
import { getAllStudents, getAllFeeStatuses, setFeeStatus } from '../student/usersData';

const WardenFeeStatus = () => {
  const [students, setStudents] = useState([]);
  const [feeStatuses, setFeeStatuses] = useState({});
  const [edit, setEdit] = useState(null);
  const [form, setForm] = useState({ due: '', lastPaid: '', nextDue: '', status: 'Due' });

  useEffect(() => {
    setStudents(getAllStudents());
    setFeeStatuses(getAllFeeStatuses());
  }, []);

  const handleEdit = (email) => {
    setEdit(email);
    setForm(feeStatuses[email] || { due: '', lastPaid: '', nextDue: '', status: 'Due' });
  };

  const handleChange = e => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSave = (email) => {
    setFeeStatus(email, form);
    setFeeStatuses(getAllFeeStatuses());
    setEdit(null);
  };

  return (
    <div className="complaint-container">
      <CommonHeader title="Fee Status (All Students)" userRole="warden" showMenu={true} showBackButton={true} />
      <div className="complaint-content-wrapper">
        <div className="complaint-content" style={{maxWidth: 900}}>
          <h2 style={{textAlign: 'center', color: '#185a9d', marginBottom: 18}}>All Students' Fee Status</h2>
          <table style={{width: '100%', borderCollapse: 'collapse', background: '#f8fafd', borderRadius: 10, overflow: 'hidden', boxShadow: '0 2px 8px rgba(67,206,162,0.08)'}}>
            <thead>
              <tr style={{background: '#43cea2', color: '#fff'}}>
                <th style={{padding: '10px 12px'}}>Name</th>
                <th style={{padding: '10px 12px'}}>Email</th>
                <th style={{padding: '10px 12px'}}>Fee Due</th>
                <th style={{padding: '10px 12px'}}>Last Paid</th>
                <th style={{padding: '10px 12px'}}>Next Due</th>
                <th style={{padding: '10px 12px'}}>Status</th>
                <th style={{padding: '10px 12px'}}>Action</th>
              </tr>
            </thead>
            <tbody>
              {students.length === 0 && (
                <tr><td colSpan={7} style={{textAlign: 'center', padding: 18, color: '#888'}}>No students found.</td></tr>
              )}
              {students.map(s => {
                const fee = feeStatuses[s.email] || { due: '', lastPaid: '', nextDue: '', status: 'Due' };
                if (edit === s.email) {
                  return (
                    <tr key={s.email}>
                      <td style={{padding: '10px 12px'}}>{s.name}</td>
                      <td style={{padding: '10px 12px'}}>{s.email}</td>
                      <td style={{padding: '10px 12px'}}><input name="due" value={form.due} onChange={handleChange} style={{width: 80}} /></td>
                      <td style={{padding: '10px 12px'}}><input name="lastPaid" value={form.lastPaid} onChange={handleChange} style={{width: 110}} /></td>
                      <td style={{padding: '10px 12px'}}><input name="nextDue" value={form.nextDue} onChange={handleChange} style={{width: 110}} /></td>
                      <td style={{padding: '10px 12px'}}>
                        <select name="status" value={form.status} onChange={handleChange}>
                          <option value="Due">Due</option>
                          <option value="Paid">Paid</option>
                        </select>
                      </td>
                      <td style={{padding: '10px 12px'}}>
                        <button onClick={() => handleSave(s.email)} style={{background: '#1ca97a', color: '#fff', border: 'none', borderRadius: 6, padding: '6px 14px', fontWeight: 600, cursor: 'pointer'}}>Save</button>
                        <button onClick={() => setEdit(null)} style={{marginLeft: 8, background: '#e53e3e', color: '#fff', border: 'none', borderRadius: 6, padding: '6px 14px', fontWeight: 600, cursor: 'pointer'}}>Cancel</button>
                      </td>
                    </tr>
                  );
                } else {
                  return (
                    <tr key={s.email}>
                      <td style={{padding: '10px 12px'}}>{s.name}</td>
                      <td style={{padding: '10px 12px'}}>{s.email}</td>
                      <td style={{padding: '10px 12px'}}>₹{fee.due}</td>
                      <td style={{padding: '10px 12px'}}>{fee.lastPaid}</td>
                      <td style={{padding: '10px 12px'}}>{fee.nextDue}</td>
                      <td style={{padding: '10px 12px', color: fee.status === 'Due' ? '#e53e3e' : '#1ca97a', fontWeight: 600}}>{fee.status}</td>
                      <td style={{padding: '10px 12px'}}>
                        <button onClick={() => handleEdit(s.email)} style={{background: '#185a9d', color: '#fff', border: 'none', borderRadius: 6, padding: '6px 14px', fontWeight: 600, cursor: 'pointer'}}>Edit</button>
                      </td>
                    </tr>
                  );
                }
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default WardenFeeStatus; 