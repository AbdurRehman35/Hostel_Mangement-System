import React, { useState, useEffect } from 'react';
import CommonHeader from '../CommonHeader';

const getRooms = () => JSON.parse(localStorage.getItem('rooms') || '{}');
const saveRooms = (rooms) => localStorage.setItem('rooms', JSON.stringify(rooms));

const WardenRoomManagement = () => {
  const [rooms, setRooms] = useState(getRooms());
  const [form, setForm] = useState({ roomNumber: '', floor: '', roommates: '', capacity: '' });
  const [success, setSuccess] = useState(false);

  useEffect(() => {
    setRooms(getRooms());
  }, []);

  const handleChange = e => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = e => {
    e.preventDefault();
    const { roomNumber, floor, roommates, capacity } = form;
    if (!roomNumber || !floor || !capacity) return;
    const newRooms = {
      ...rooms,
      [roomNumber]: {
        floor: Number(floor),
        capacity: Number(capacity),
        roommates: roommates.split(',').map(s => s.trim()).filter(Boolean),
      },
    };
    setRooms(newRooms);
    saveRooms(newRooms);
    setForm({ roomNumber: '', floor: '', roommates: '', capacity: '' });
    setSuccess(true);
    setTimeout(() => setSuccess(false), 2000);
  };

  return (
    <div className="complaint-container">
      <CommonHeader title="Room Management" userRole="warden" showMenu={true} showBackButton={true} />
      <div className="complaint-content-wrapper">
        <div className="complaint-content" style={{maxWidth: 650}}>
          <h2 style={{textAlign: 'center', color: '#185a9d', marginBottom: 18}}>Manage Rooms</h2>
          {success && <div className="complaint-success">Room info saved!</div>}
          <form className="complaint-form" onSubmit={handleSubmit} style={{marginBottom: 24}}>
            <div className="form-group">
              <label className="form-label">Room Number *</label>
              <input name="roomNumber" className="form-input" value={form.roomNumber} onChange={handleChange} required />
            </div>
            <div className="form-group">
              <label className="form-label">Floor *</label>
              <input name="floor" className="form-input" value={form.floor} onChange={handleChange} required type="number" min="1" />
            </div>
            <div className="form-group">
              <label className="form-label">Capacity *</label>
              <input name="capacity" className="form-input" value={form.capacity} onChange={handleChange} required type="number" min="1" />
            </div>
            <div className="form-group">
              <label className="form-label">Roommates (comma separated)</label>
              <input name="roommates" className="form-input" value={form.roommates} onChange={handleChange} placeholder="e.g. Alice Sharma, Rahul Verma" />
            </div>
            <button type="submit" className="submit-btn">Save Room Info</button>
          </form>
          <h3 style={{color: '#185a9d', marginBottom: 10}}>All Rooms</h3>
          <table style={{width: '100%', borderCollapse: 'collapse', background: '#f8fafd', borderRadius: 10, overflow: 'hidden', boxShadow: '0 2px 8px rgba(67,206,162,0.08)'}}>
            <thead>
              <tr style={{background: '#43cea2', color: '#fff'}}>
                <th style={{padding: '10px 12px'}}>Room</th>
                <th style={{padding: '10px 12px'}}>Floor</th>
                <th style={{padding: '10px 12px'}}>Capacity</th>
                <th style={{padding: '10px 12px'}}>Roommates</th>
                <th style={{padding: '10px 12px'}}>Available Beds</th>
              </tr>
            </thead>
            <tbody>
              {Object.entries(rooms).map(([room, info]) => (
                <tr key={room}>
                  <td style={{padding: '10px 12px'}}>{room}</td>
                  <td style={{padding: '10px 12px'}}>{info.floor}</td>
                  <td style={{padding: '10px 12px'}}>{info.capacity || '-'}</td>
                  <td style={{padding: '10px 12px'}}>{info.roommates.join(', ')}</td>
                  <td style={{padding: '10px 12px'}}>{info.capacity ? info.capacity - info.roommates.length : '-'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default WardenRoomManagement; 