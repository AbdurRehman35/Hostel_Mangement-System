import React, { useEffect, useState } from 'react';
import CommonHeader from '../CommonHeader';
import { getAllStudents } from '../student/usersData';
import { useUser } from '../../UserContext';

const getRooms = () => JSON.parse(localStorage.getItem('rooms') || '{}');

const WardenStudentList = () => {
  const [students, setStudents] = useState([]);
  const [rooms, setRooms] = useState({});
  const { user } = useUser();

  useEffect(() => {
    setStudents(getAllStudents());
    setRooms(getRooms());
  }, []);

  // Find room for each student
  const getStudentRoom = (studentName) => {
    for (const [room, info] of Object.entries(rooms)) {
      if (info.roommates.some(r => r.toLowerCase() === studentName.toLowerCase())) {
        return room;
      }
    }
    return '-';
  };

  // Only show students in the warden's block
  const filteredStudents = user && user.block ? students.filter(s => s.block && s.block.toLowerCase() === user.block.toLowerCase()) : [];

  return (
    <div className="complaint-container">
      <CommonHeader title="Student List & Room Info" userRole="warden" showMenu={true} showBackButton={true} />
      <div className="complaint-content-wrapper">
        <div className="complaint-content" style={{maxWidth: 800}}>
          <h2 style={{textAlign: 'center', color: '#185a9d', marginBottom: 18}}>Students in Your Block</h2>
          <table style={{width: '100%', borderCollapse: 'collapse', background: '#f8fafd', borderRadius: 10, overflow: 'hidden', boxShadow: '0 2px 8px rgba(67,206,162,0.08)'}}>
            <thead>
              <tr style={{background: '#43cea2', color: '#fff'}}>
                <th style={{padding: '10px 12px'}}>Name</th>
                <th style={{padding: '10px 12px'}}>Email</th>
                <th style={{padding: '10px 12px'}}>Room</th>
              </tr>
            </thead>
            <tbody>
              {filteredStudents.length === 0 && (
                <tr><td colSpan={3} style={{textAlign: 'center', padding: 18, color: '#888'}}>No students found in your block.</td></tr>
              )}
              {filteredStudents.map(s => (
                <tr key={s.email}>
                  <td style={{padding: '10px 12px'}}>{s.name}</td>
                  <td style={{padding: '10px 12px'}}>{s.email}</td>
                  <td style={{padding: '10px 12px'}}>{getStudentRoom(s.name)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default WardenStudentList; 