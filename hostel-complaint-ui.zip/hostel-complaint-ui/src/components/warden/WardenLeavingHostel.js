import React, { useState, useEffect } from 'react';
import CommonHeader from '../CommonHeader';

const LEAVING_KEY = 'leavingHostelApplications';

function getAllLeavingApplications() {
  return JSON.parse(localStorage.getItem(LEAVING_KEY) || '[]');
}

function updateLeavingApplicationStatus(id, status) {
  const all = getAllLeavingApplications();
  const updated = all.map(app => app.id === id ? { ...app, status } : app);
  localStorage.setItem(LEAVING_KEY, JSON.stringify(updated));
}

const statusColor = status => {
  if (status === 'Approved') return '#1ca97a';
  if (status === 'Rejected') return '#e53e3e';
  return '#185a9d';
};

const WardenLeavingHostel = () => {
  const [applications, setApplications] = useState([]);

  useEffect(() => {
    setApplications(getAllLeavingApplications());
  }, []);

  const handleAction = (id, status) => {
    updateLeavingApplicationStatus(id, status);
    setApplications(getAllLeavingApplications());
  };

  return (
    <div className="complaint-container">
      <CommonHeader title="Leaving Hostel Approvals" userRole="warden" showMenu={true} showBackButton={true} />
      <div className="complaint-content-wrapper">
        <div className="complaint-content" style={{maxWidth: 800}}>
          <h2 style={{textAlign: 'center', color: '#185a9d', marginBottom: 18}}>Leaving Hostel Applications</h2>
          <table style={{width: '100%', borderCollapse: 'collapse', background: '#f8fafd', borderRadius: 10, overflow: 'hidden', boxShadow: '0 2px 8px rgba(67,206,162,0.08)'}}>
            <thead>
              <tr style={{background: '#43cea2', color: '#fff'}}>
                <th style={{padding: '10px 12px'}}>Student</th>
                <th style={{padding: '10px 12px'}}>Applied On</th>
                <th style={{padding: '10px 12px'}}>Leaving Date</th>
                <th style={{padding: '10px 12px'}}>Reason</th>
                <th style={{padding: '10px 12px'}}>Status</th>
                <th style={{padding: '10px 12px'}}>Action</th>
              </tr>
            </thead>
            <tbody>
              {applications.length === 0 && (
                <tr><td colSpan={6} style={{textAlign: 'center', padding: 18, color: '#888'}}>No applications yet.</td></tr>
              )}
              {applications.map(app => (
                <tr key={app.id}>
                  <td style={{padding: '10px 12px'}}>{app.student}</td>
                  <td style={{padding: '10px 12px'}}>{app.dateApplied}</td>
                  <td style={{padding: '10px 12px'}}>{app.leavingDate}</td>
                  <td style={{padding: '10px 12px'}}>{app.reason}</td>
                  <td style={{padding: '10px 12px'}}>
                    <span style={{
                      background: statusColor(app.status),
                      color: '#fff',
                      borderRadius: 6,
                      padding: '4px 12px',
                      fontWeight: 600,
                      fontSize: '0.98rem',
                    }}>{app.status}</span>
                  </td>
                  <td style={{padding: '10px 12px'}}>
                    {app.status === 'Pending' && (
                      <>
                        <button style={{marginRight: 8, background: '#1ca97a', color: '#fff', border: 'none', borderRadius: 6, padding: '6px 14px', fontWeight: 600, cursor: 'pointer'}} onClick={() => handleAction(app.id, 'Approved')}>Approve</button>
                        <button style={{background: '#e53e3e', color: '#fff', border: 'none', borderRadius: 6, padding: '6px 14px', fontWeight: 600, cursor: 'pointer'}} onClick={() => handleAction(app.id, 'Rejected')}>Reject</button>
                      </>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default WardenLeavingHostel; 