import React from 'react';
import { useNavigate } from 'react-router-dom';

const BackButton = () => {
  const navigate = useNavigate();
  return (
    <button
      onClick={() => navigate(-1)}
      style={{
        background: 'none',
        border: 'none',
        color: '#185a9d',
        fontSize: '1.1rem',
        fontWeight: 600,
        cursor: 'pointer',
        marginBottom: '1rem',
        display: 'flex',
        alignItems: 'center',
        gap: '0.5rem',
      }}
      aria-label="Go back"
    >
      <span style={{fontSize: '1.3rem'}}>&larr;</span> Back
    </button>
  );
};

export default BackButton; 