// Simple in-memory complaints data store for demo purposes
// In production, replace with API/backend

const COMPLAINTS_KEY = 'complaints';

function loadComplaints() {
  return JSON.parse(localStorage.getItem(COMPLAINTS_KEY) || '[]');
}

function saveComplaints(data) {
  localStorage.setItem(COMPLAINTS_KEY, JSON.stringify(data));
}

export function getComplaints() {
  return loadComplaints();
}

export function addComplaint(complaint) {
  const complaints = loadComplaints();
  const newComplaint = { ...complaint, id: Date.now(), status: 'Pending', date: new Date().toISOString().slice(0, 10) };
  const updated = [...complaints, newComplaint];
  saveComplaints(updated);
}

export function resolveComplaint(id) {
  const complaints = loadComplaints();
  const updated = complaints.map(c =>
    c.id === id ? { ...c, status: 'Resolved' } : c
  );
  saveComplaints(updated);
} 