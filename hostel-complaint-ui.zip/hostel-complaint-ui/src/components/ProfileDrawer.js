import React, { useState, useEffect } from 'react';
import './ProfileDrawer.css';
import { FaUserCircle, FaEdit, FaSave, FaSignOutAlt, FaTimes, FaTimesCircle } from 'react-icons/fa';
import { useNavigate } from 'react-router-dom';

const ProfileDrawer = ({ isOpen, onClose, user, updateUser, clearUser }) => {
  const [edit, setEdit] = useState(false);
  const [form, setForm] = useState(user || { name: '', email: '', role: '' });
  const navigate = useNavigate();
  const [showSignOutConfirm, setShowSignOutConfirm] = useState(false);

  useEffect(() => {
    setForm(user || { name: '', email: '', role: '' });
  }, [user]);

  if (!user || !user.name) return null;

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSave = (e) => {
    e.preventDefault();
    updateUser(form);
    setEdit(false);
  };

  const handleSignOut = () => {
    clearUser();
    onClose();
  };

  return (
    <div className={`profile-drawer${isOpen ? ' open' : ''}`}> 
      <div className="profile-drawer-gradient-header">
        <div className="profile-avatar-large">
          <FaUserCircle size={70} color="#fff" />
        </div>
        <div style={{marginLeft: 18, color: '#fff', fontWeight: 600, fontSize: '1.2rem', flex: 1}}>{user?.name || ''}</div>
        <button className="profile-drawer-close" onClick={onClose} title="Close">
          <FaTimesCircle size={28} />
        </button>
      </div>
      <div className="profile-drawer-content">
        {edit ? (
          <form onSubmit={handleSave} className="profile-form">
            <label>Name</label>
            <input name="name" value={form.name} onChange={handleChange} />
            <label>Email</label>
            <input name="email" value={form.email} disabled />
            <label>Role</label>
            <input name="role" value={form.role} disabled />
            <div className="profile-drawer-actions">
              <button type="submit" className="profile-save-btn" title="Save"><FaSave /> Save</button>
              <button type="button" className="profile-cancel-btn" onClick={() => setEdit(false)} title="Cancel"><FaTimes /> Cancel</button>
            </div>
          </form>
        ) : (
          <>
            <div className="profile-info-row profile-info-name"><b>Name:</b> {user?.name || ''}</div>
            <div className="profile-info-row"><b>Email:</b> {user?.email || ''}</div>
            <div className="profile-info-row"><b>Role:</b> {user?.role || ''}</div>
            <hr style={{margin: '1.2rem 0 0.7rem 0', border: 'none', borderTop: '1.5px solid #eee'}} />
            <div style={{fontWeight: 600, color: '#185a9d', marginBottom: 8, fontSize: '1.08rem'}}>Account Actions</div>
            <div className="profile-drawer-actions">
              <button className="profile-edit-btn" onClick={() => setEdit(true)} title="Edit Info"><FaEdit /> Edit Info</button>
              {(user?.role === 'Student' || user?.role === 'Warden') && (
                <>
                  <button className="profile-edit-btn" onClick={() => { navigate(`/${user.role.toLowerCase()}/change-password`); onClose(); }} title="Change Password">Change Password</button>
                  <button className="profile-edit-btn" onClick={() => { navigate(`/${user.role.toLowerCase()}/change-password`); onClose(); }} title="Forgot Password?">Forgot Password?</button>
                </>
              )}
              <button className="profile-signout-btn" onClick={() => setShowSignOutConfirm(true)} title="Sign Out"><FaSignOutAlt /> Sign Out</button>
            </div>
            {showSignOutConfirm && (
              <div className="signout-confirm-overlay">
                <div className="signout-confirm-dialog">
                  <div style={{marginBottom: 16, fontWeight: 600, color: '#185a9d', fontSize: '1.08rem'}}>Are you sure you want to sign out?</div>
                  <div style={{display: 'flex', gap: 12, justifyContent: 'flex-end'}}>
                    <button className="profile-cancel-btn" onClick={() => setShowSignOutConfirm(false)} title="Cancel">Cancel</button>
                    <button className="profile-signout-btn" onClick={handleSignOut} title="Sign Out">Sign Out</button>
                  </div>
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};

export default ProfileDrawer; 