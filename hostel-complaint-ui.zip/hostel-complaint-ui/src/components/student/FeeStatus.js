import React from 'react';
import CommonHeader from '../CommonHeader';

const mockFee = {
  due: 2500,
  lastPaid: '2024-06-01',
  nextDue: '2024-09-01',
  status: 'Due',
};

const FeeStatus = () => (
  <div className="complaint-container">
    <CommonHeader title="Fee Status" userRole="student" showMenu={true} showBackButton={true} />
    <div className="complaint-content-wrapper">
      <div className="complaint-content" style={{maxWidth: 500}}>
        <h2 style={{textAlign: 'center', color: '#185a9d', marginBottom: 18}}>Fee Details</h2>
        <table style={{width: '100%', borderCollapse: 'collapse', marginBottom: 18, background: '#f8fafd', borderRadius: 10, overflow: 'hidden', boxShadow: '0 2px 8px rgba(67,206,162,0.08)'}}>
          <tbody>
            <tr style={{background: '#43cea2', color: '#fff'}}>
              <th style={{padding: '10px 12px', textAlign: 'left'}}>Fee Due</th>
              <td style={{padding: '10px 12px'}}>₹{mockFee.due}</td>
            </tr>
            <tr>
              <th style={{padding: '10px 12px', textAlign: 'left'}}>Last Paid</th>
              <td style={{padding: '10px 12px'}}>{mockFee.lastPaid}</td>
            </tr>
            <tr>
              <th style={{padding: '10px 12px', textAlign: 'left'}}>Next Due Date</th>
              <td style={{padding: '10px 12px'}}>{mockFee.nextDue}</td>
            </tr>
            <tr>
              <th style={{padding: '10px 12px', textAlign: 'left'}}>Status</th>
              <td style={{padding: '10px 12px', color: mockFee.status === 'Due' ? '#e53e3e' : '#1ca97a', fontWeight: 600}}>{mockFee.status}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
);

export default FeeStatus; 