import React, { useState } from 'react';
import CommonHeader from '../CommonHeader';
import { addComplaint } from '../complaintsData';
import './SubmitComplaint.css';

const SubmitComplaint = () => {
  const [photo, setPhoto] = useState(null);
  const [formData, setFormData] = useState({
    issueType: '',
    description: ''
  });
  const [success, setSuccess] = useState(false);

  const handlePhotoChange = (e) => {
    setPhoto(e.target.files[0]);
  };

  const handleInputChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    addComplaint({
      type: formData.issueType,
      description: formData.description,
      student: 'John Doe', // Demo name
      photo: photo ? photo.name : null
    });
    setFormData({ issueType: '', description: '' });
    setPhoto(null);
    setSuccess(true);
    setTimeout(() => setSuccess(false), 2000);
  };

  return (
    <div className="complaint-container">
      <CommonHeader 
        title="Submit Complaint" 
        userRole="student"
        showMenu={true}
        showBackButton={true}
      />
      <div className="complaint-content-wrapper">
        <main className="complaint-main">
          <div className="complaint-content">
            <div className="complaint-header">
              <h1 className="complaint-title">Submit Room Complaint</h1>
              <p className="complaint-subtitle">Report an issue or concern about your hostel room</p>
            </div>
            {success && <div className="complaint-success">Complaint submitted successfully!</div>}
            <form className="complaint-form" onSubmit={handleSubmit}>
              <div className="form-group">
                <label className="form-label">Issue Type *</label>
                <select 
                  className="form-input" 
                  name="issueType"
                  value={formData.issueType}
                  onChange={handleInputChange}
                  required
                >
                  <option value="">Select Issue Type</option>
                  <option value="Broken Fan">Broken Fan</option>
                  <option value="Dirty Washroom">Dirty Washroom</option>
                  <option value="Broken Furniture">Broken Furniture</option>
                  <option value="Lighting Issue">Lighting Issue</option>
                  <option value="Cleanliness">Cleanliness</option>
                  <option value="Other">Other</option>
                </select>
              </div>
              <div className="form-group">
                <label className="form-label">Description *</label>
                <textarea 
                  className="form-input form-textarea" 
                  name="description"
                  value={formData.description}
                  onChange={handleInputChange}
                  placeholder="Please describe the issue in detail..." 
                  rows={4} 
                  required 
                />
              </div>
              <div className="form-group">
                <label className="form-label">Attach Photo (optional)</label>
                <label className="file-upload">
                  <input 
                    type="file" 
                    accept="image/*" 
                    className="file-input" 
                    onChange={handlePhotoChange} 
                  />
                  <div className="file-upload-content">
                    <span className="file-icon">📷</span>
                    <span className="file-text">
                      {photo ? photo.name : 'Choose a photo or drag it here'}
                    </span>
                  </div>
                </label>
                {photo && (
                  <div className="file-preview">
                    <span className="preview-icon">✅</span>
                    <span className="preview-text">Selected: {photo.name}</span>
                  </div>
                )}
              </div>
              <button type="submit" className="submit-btn">
                Submit Complaint
              </button>
            </form>
          </div>
        </main>
      </div>
    </div>
  );
};

export default SubmitComplaint; 