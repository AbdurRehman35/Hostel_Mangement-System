import React from 'react';
import CommonHeader from '../CommonHeader';
import './StudentRegistration.css';
import { useUser } from '../../UserContext';

const StudentRegistration = () => {
  const { updateUser } = useUser();

  const handleSubmit = (e) => {
    e.preventDefault();
    const name = e.target[0].value;
    const email = e.target[1].value;
    updateUser({ name, email, role: 'Student' });
    alert('Registration successful!');
    // Optionally redirect to dashboard or login
  };

  return (
    <div className="reg-container">
      <CommonHeader 
        title="Student Registration" 
        userRole="student"
        showMenu={false}
        showBackButton={true}
      />
      <div className="reg-content">
        <div className="reg-form">
          <h2 className="reg-title">Student Registration</h2>
          <div style={{textAlign: 'center', color: '#e53e3e', fontWeight: 500, fontSize: '1.1rem', marginTop: 24}}>
            Registration is handled by the admin. Please contact the hostel office to get your account.
          </div>
          <div className="already-registered-link">
            <span>Already registered? </span>
            <a href="/login" style={{ color: '#1a4b7a', fontWeight: 600, textDecoration: 'underline', cursor: 'pointer' }}>Login here</a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StudentRegistration; 