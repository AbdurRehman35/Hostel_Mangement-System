import React, { useState, useEffect } from 'react';
import CommonHeader from '../CommonHeader';
import { getLeaveApplications, addLeaveApplication } from './studentData';
import { useUser } from '../../UserContext';

const statusColor = status => {
  if (status === 'Approved') return '#1ca97a';
  if (status === 'Rejected') return '#e53e3e';
  return '#185a9d';
};

const LeaveApplication = () => {
  const [leaves, setLeaves] = useState([]);
  const [form, setForm] = useState({ from: '', to: '', reason: '' });
  const [success, setSuccess] = useState(false);
  const { user } = useUser();

  useEffect(() => {
    if (user && user.name) {
      setLeaves(getLeaveApplications(user.name));
    }
  }, [user]);

  const handleChange = e => setForm({ ...form, [e.target.name]: e.target.value });
  const handleSubmit = e => {
    e.preventDefault();
    if (!user || !user.name) return;
    const newApp = {
      id: Date.now(),
      ...form,
      status: 'Pending',
      student: user.name,
    };
    addLeaveApplication(newApp);
    setLeaves([newApp, ...leaves]);
    setForm({ from: '', to: '', reason: '' });
    setSuccess(true);
    setTimeout(() => setSuccess(false), 2000);
  };

  return (
    <div className="complaint-container">
      <CommonHeader title="Leave Application" userRole="student" showMenu={true} showBackButton={true} />
      <div className="complaint-content-wrapper">
        <div className="complaint-content" style={{maxWidth: 650}}>
          <h2 style={{textAlign: 'center', color: '#185a9d', marginBottom: 18}}>Apply for Hostel Leave</h2>
          <div style={{marginBottom: 32, background: '#f8fafd', borderRadius: 10, padding: '18px 22px', boxShadow: '0 2px 8px rgba(67,206,162,0.07)'}}>
            {success && <div className="complaint-success">Leave application submitted!</div>}
            <form className="complaint-form" onSubmit={handleSubmit}>
              <div className="form-group">
                <label className="form-label">From Date *</label>
                <input type="date" name="from" className="form-input" value={form.from} onChange={handleChange} required />
              </div>
              <div className="form-group">
                <label className="form-label">To Date *</label>
                <input type="date" name="to" className="form-input" value={form.to} onChange={handleChange} required />
              </div>
              <div className="form-group">
                <label className="form-label">Reason *</label>
                <input type="text" name="reason" className="form-input" value={form.reason} onChange={handleChange} required placeholder="Reason for leave" />
              </div>
              <button type="submit" className="submit-btn">Apply for Leave</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LeaveApplication; 