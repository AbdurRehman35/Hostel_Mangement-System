import React from 'react';
import { useNavigate } from 'react-router-dom';
import CommonHeader from '../CommonHeader';
import './StudentDashboard.css';

const StudentDashboard = () => {
  const navigate = useNavigate();
  
  return (
    <div className="dashboard-container">
      <CommonHeader 
        title="Student Dashboard" 
        userRole="student"
        showMenu={true}
        showBackButton={false}
      />
      
      <main className="dashboard-main">
        <div className="dashboard-content">
          <div className="welcome-section">
            <h1 className="welcome-title">Welcome back, Student! 👋</h1>
            <p className="welcome-subtitle">Manage your hostel complaints and stay updated</p>
          </div>
          
          <div className="dashboard-grid">
            <div className="dashboard-card" onClick={() => navigate('/student/submit-complaint')}>
              <div className="card-icon">📝</div>
              <h3 className="card-title">Submit Complaint</h3>
              <p className="card-description">Report a new issue or concern</p>
            </div>
            <div className="dashboard-card" onClick={() => navigate('/student/complaint-history')}>
              <div className="card-icon">📋</div>
              <h3 className="card-title">Complaint History</h3>
              <p className="card-description">View all your submitted complaints</p>
            </div>
            <div className="dashboard-card" onClick={() => navigate('/student/notifications')}>
              <div className="card-icon">🔔</div>
              <h3 className="card-title">Notifications</h3>
              <p className="card-description">Check updates and announcements</p>
            </div>
            <div className="dashboard-card" onClick={() => navigate('/student/room-info')}>
              <div className="card-icon">🏠</div>
              <h3 className="card-title">Room Information</h3>
              <p className="card-description">View assigned room, roommates, floor, etc.</p>
            </div>
            <div className="dashboard-card" onClick={() => navigate('/student/hostel-rules')}>
              <div className="card-icon">📜</div>
              <h3 className="card-title">Hostel Rules & Regulations</h3>
              <p className="card-description">Read hostel policies and guidelines</p>
            </div>
            <div className="dashboard-card" onClick={() => navigate('/student/leave-application')}>
              <div className="card-icon">🏖️</div>
              <h3 className="card-title">Leave Application</h3>
              <p className="card-description">Apply for leave and view status</p>
            </div>
            <div className="dashboard-card" onClick={() => navigate('/student/fee-status')}>
              <div className="card-icon">💳</div>
              <h3 className="card-title">Fee Status</h3>
              <p className="card-description">See fee dues, last paid, next due date</p>
            </div>
            <div className="dashboard-card" onClick={() => navigate('/student/room-change-request')}>
              <div className="card-icon">🔄</div>
              <h3 className="card-title">Room Change Request</h3>
              <p className="card-description">Apply for a room change and view status</p>
            </div>
            <div className="dashboard-card" onClick={() => navigate('/student/application-history')}>
              <div className="card-icon">📑</div>
              <h3 className="card-title">Application History</h3>
              <p className="card-description">View all your leave and room change requests</p>
            </div>
            <div className="dashboard-card" onClick={() => navigate('/student/leaving-hostel')}>
              <div className="card-icon">🚪</div>
              <h3 className="card-title">Leaving Hostel</h3>
              <p className="card-description">Apply to leave hostel permanently</p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default StudentDashboard; 