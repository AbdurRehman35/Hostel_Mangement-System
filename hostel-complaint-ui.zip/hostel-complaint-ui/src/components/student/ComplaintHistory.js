import React, { useEffect, useState } from 'react';
import CommonHeader from '../CommonHeader';
import { getComplaints } from '../complaintsData';
import './ComplaintHistory.css';

const ComplaintHistory = () => {
  const [complaints, setComplaints] = useState([]);

  useEffect(() => {
    // For demo, filter by student name
    const all = getComplaints();
    setComplaints(all.filter(c => c.student === 'John Doe'));
  }, []);

  return (
    <div className="complaint-history-container">
      <CommonHeader 
        title="Complaint History" 
        userRole="student"
        showMenu={true}
      />
      <main className="complaint-history-main">
        <div className="complaint-history-content">
          <h1 className="complaint-history-title">Your Complaints</h1>
          <div className="complaint-list">
            {complaints.length === 0 && <div className="complaint-empty">No complaints submitted yet.</div>}
            {complaints.map((complaint) => (
              <div className="complaint-card" key={complaint.id}>
                <div className="complaint-type">{complaint.type}</div>
                <div className={`complaint-status status-${complaint.status.replace(/\s/g, '').toLowerCase()}`}>{complaint.status}</div>
                <div className="complaint-date">{complaint.date}</div>
                <div className="complaint-desc">{complaint.description}</div>
                {complaint.photo && <div className="complaint-photo">📷 {complaint.photo}</div>}
              </div>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
};

export default ComplaintHistory; 