import React from 'react';
import CommonHeader from '../CommonHeader';
import './NotificationCenter.css';

const NotificationCenter = () => {
  // Dummy notifications for demonstration
  const notifications = [
    { id: 1, message: 'Your complaint about the fan has been resolved.', date: '2024-05-06' },
    { id: 2, message: 'Warden scheduled an inspection for your room.', date: '2024-05-05' },
    { id: 3, message: 'New announcement: Hostel cleaning on Sunday.', date: '2024-05-03' },
  ];

  return (
    <div className="notification-center-container">
      <CommonHeader 
        title="Notifications" 
        userRole="student"
        showMenu={true}
      />
      <main className="notification-center-main">
        <div className="notification-center-content">
          <h1 className="notification-center-title">Notifications</h1>
          <div className="notification-list">
            {notifications.map((notification) => (
              <div className="notification-card" key={notification.id}>
                <div className="notification-message">{notification.message}</div>
                <div className="notification-date">{notification.date}</div>
              </div>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
};

export default NotificationCenter; 