import React, { useState, useEffect } from 'react';
import CommonHeader from '../CommonHeader';
import { getRoomChangeRequests, addRoomChangeRequest } from './studentData';
import { useUser } from '../../UserContext';

const getRooms = () => JSON.parse(localStorage.getItem('rooms') || '{}');

const statusColor = status => {
  if (status === 'Approved') return '#1ca97a';
  if (status === 'Rejected') return '#e53e3e';
  return '#185a9d';
};

const RoomChangeRequest = () => {
  const [requests, setRequests] = useState([]);
  const [form, setForm] = useState({ preferred: '', reason: '' });
  const [success, setSuccess] = useState(false);
  const { user } = useUser();
  const rooms = getRooms();
  const availableRooms = Object.entries(rooms).filter(
    ([, info]) => info.capacity && info.roommates.length < info.capacity
  );

  useEffect(() => {
    if (user && user.name) {
      setRequests(getRoomChangeRequests(user.name));
    }
  }, [user]);

  const handleChange = e => setForm({ ...form, [e.target.name]: e.target.value });
  const handleSubmit = e => {
    e.preventDefault();
    if (!user || !user.name) return;
    const newReq = {
      id: Date.now(),
      date: new Date().toISOString().slice(0, 10),
      ...form,
      status: 'Pending',
      student: user.name,
    };
    addRoomChangeRequest(newReq);
    setRequests([newReq, ...requests]);
    setForm({ preferred: '', reason: '' });
    setSuccess(true);
    setTimeout(() => setSuccess(false), 2000);
  };

  return (
    <div className="complaint-container">
      <CommonHeader title="Room Change Request" userRole="student" showMenu={true} showBackButton={true} />
      <div className="complaint-content-wrapper">
        <div className="complaint-content" style={{maxWidth: 650}}>
          <h2 style={{textAlign: 'center', color: '#185a9d', marginBottom: 18}}>Request Room Change</h2>
          <div style={{marginBottom: 32, background: '#f8fafd', borderRadius: 10, padding: '18px 22px', boxShadow: '0 2px 8px rgba(67,206,162,0.07)'}}>
            {success && <div className="complaint-success">Room change request submitted!</div>}
            <form className="complaint-form" onSubmit={handleSubmit}>
              <div className="form-group">
                <label className="form-label">Preferred Room</label>
                <select name="preferred" className="form-input" value={form.preferred} onChange={handleChange} required>
                  <option value="">Select a room</option>
                  {availableRooms.map(([room, info]) => (
                    <option key={room} value={room}>
                      {room} (Floor {info.floor}, {info.capacity - info.roommates.length} beds available)
                    </option>
                  ))}
                </select>
              </div>
              <div className="form-group">
                <label className="form-label">Reason *</label>
                <input type="text" name="reason" className="form-input" value={form.reason} onChange={handleChange} required placeholder="Reason for room change" />
              </div>
              <button type="submit" className="submit-btn">Submit Request</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RoomChangeRequest; 