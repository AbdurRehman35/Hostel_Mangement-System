// Persistent user management utility for students and wardens

const STUDENTS_KEY = 'students';
const WARDENS_KEY = 'wardens';
const FEE_KEY = 'feeStatus';
const NOTIF_KEY = 'notifications';

export function getAllStudents() {
  return JSON.parse(localStorage.getItem(STUDENTS_KEY) || '[]');
}

export function addStudent(student) {
  const all = getAllStudents();
  all.push({ ...student, addedAt: new Date().toISOString() });
  localStorage.setItem(STUDENTS_KEY, JSON.stringify(all));
}

export function removeStudent(email) {
  const all = getAllStudents().filter(s => s.email !== email);
  localStorage.setItem(STUDENTS_KEY, JSON.stringify(all));
}

export function getAllWardens() {
  return JSON.parse(localStorage.getItem(WARDENS_KEY) || '[]');
}

export function addWarden(warden) {
  const all = getAllWardens();
  all.push({ ...warden, addedAt: new Date().toISOString() });
  localStorage.setItem(WARDENS_KEY, JSON.stringify(all));
}

export function removeWarden(email) {
  const all = getAllWardens().filter(w => w.email !== email);
  localStorage.setItem(WARDENS_KEY, JSON.stringify(all));
}

export function getFeeStatus(email) {
  const all = JSON.parse(localStorage.getItem(FEE_KEY) || '{}');
  return all[email] || { due: 0, lastPaid: '', nextDue: '', status: 'Due' };
}

export function setFeeStatus(email, feeObj) {
  const all = JSON.parse(localStorage.getItem(FEE_KEY) || '{}');
  all[email] = feeObj;
  localStorage.setItem(FEE_KEY, JSON.stringify(all));
}

export function getAllFeeStatuses() {
  return JSON.parse(localStorage.getItem(FEE_KEY) || '{}');
}

export function getNotifications(email) {
  const all = JSON.parse(localStorage.getItem(NOTIF_KEY) || '{}');
  // Merge global ('all') and personal notifications
  return [...(all['all'] || []), ...(all[email] || [])].sort((a, b) => b.id - a.id);
}

export function addNotification(email, notification) {
  const all = JSON.parse(localStorage.getItem(NOTIF_KEY) || '{}');
  if (!all[email]) all[email] = [];
  all[email].unshift(notification);
  localStorage.setItem(NOTIF_KEY, JSON.stringify(all));
}

export function getAllNotifications() {
  return JSON.parse(localStorage.getItem(NOTIF_KEY) || '{}');
}

export function getStudentByEmail(email) {
  return getAllStudents().find(s => s.email === email);
}

export function getWardenByEmail(email) {
  return getAllWardens().find(w => w.email === email);
}

export function updateStudentPassword(email, newPassword) {
  const all = getAllStudents();
  const idx = all.findIndex(s => s.email === email);
  if (idx !== -1) {
    all[idx].password = newPassword;
    localStorage.setItem(STUDENTS_KEY, JSON.stringify(all));
  }
}

export function updateWardenPassword(email, newPassword) {
  const all = getAllWardens();
  const idx = all.findIndex(w => w.email === email);
  if (idx !== -1) {
    all[idx].password = newPassword;
    localStorage.setItem(WARDENS_KEY, JSON.stringify(all));
  }
} 