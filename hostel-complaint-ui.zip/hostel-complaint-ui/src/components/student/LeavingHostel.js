import React, { useState, useEffect } from 'react';
import CommonHeader from '../CommonHeader';
import { useUser } from '../../UserContext';

const LEAVING_KEY = 'leavingHostelApplications';

function getLeavingApplications(student) {
  const all = JSON.parse(localStorage.getItem(LEAVING_KEY) || '[]');
  if (!student) return all;
  return all.filter(app => app.student === student);
}

function addLeavingApplication(application) {
  const all = JSON.parse(localStorage.getItem(LEAVING_KEY) || '[]');
  all.unshift(application);
  localStorage.setItem(LEAVING_KEY, JSON.stringify(all));
}

const statusColor = status => {
  if (status === 'Approved') return '#1ca97a';
  if (status === 'Rejected') return '#e53e3e';
  return '#185a9d';
};

const LeavingHostel = () => {
  const [applications, setApplications] = useState([]);
  const [form, setForm] = useState({ leavingDate: '', reason: '' });
  const [success, setSuccess] = useState(false);
  const { user } = useUser();

  useEffect(() => {
    if (user && user.name) {
      setApplications(getLeavingApplications(user.name));
    }
  }, [user]);

  const handleChange = e => setForm({ ...form, [e.target.name]: e.target.value });
  const handleSubmit = e => {
    e.preventDefault();
    if (!user || !user.name) return;
    const newApp = {
      id: Date.now(),
      ...form,
      status: 'Pending',
      student: user.name,
      dateApplied: new Date().toISOString().slice(0, 10),
    };
    addLeavingApplication(newApp);
    setApplications([newApp, ...applications]);
    setForm({ leavingDate: '', reason: '' });
    setSuccess(true);
    setTimeout(() => setSuccess(false), 2000);
  };

  return (
    <div className="complaint-container">
      <CommonHeader title="Leaving Hostel" userRole="student" showMenu={true} showBackButton={true} />
      <div className="complaint-content-wrapper">
        <div className="complaint-content" style={{maxWidth: 650}}>
          <h2 style={{textAlign: 'center', color: '#185a9d', marginBottom: 18}}>Apply for Leaving Hostel</h2>
          <div style={{marginBottom: 32, background: '#f8fafd', borderRadius: 10, padding: '18px 22px', boxShadow: '0 2px 8px rgba(67,206,162,0.07)'}}>
            {success && <div className="complaint-success">Leaving hostel application submitted!</div>}
            <form className="complaint-form" onSubmit={handleSubmit}>
              <div className="form-group">
                <label className="form-label">Leaving Date *</label>
                <input type="date" name="leavingDate" className="form-input" value={form.leavingDate} onChange={handleChange} required />
              </div>
              <div className="form-group">
                <label className="form-label">Reason *</label>
                <input type="text" name="reason" className="form-input" value={form.reason} onChange={handleChange} required placeholder="Reason for leaving hostel" />
              </div>
              <button type="submit" className="submit-btn">Submit Application</button>
            </form>
          </div>
          <h3 style={{textAlign: 'center', color: '#185a9d', marginBottom: 10}}>Previous Leaving Hostel Applications</h3>
          <table style={{width: '100%', borderCollapse: 'collapse', background: '#f8fafd', borderRadius: 10, overflow: 'hidden', boxShadow: '0 2px 8px rgba(67,206,162,0.08)'}}>
            <thead>
              <tr style={{background: '#43cea2', color: '#fff'}}>
                <th style={{padding: '10px 12px'}}>Applied On</th>
                <th style={{padding: '10px 12px'}}>Leaving Date</th>
                <th style={{padding: '10px 12px'}}>Reason</th>
                <th style={{padding: '10px 12px'}}>Status</th>
              </tr>
            </thead>
            <tbody>
              {applications.length === 0 && (
                <tr><td colSpan={4} style={{textAlign: 'center', padding: 18, color: '#888'}}>No applications yet.</td></tr>
              )}
              {applications.map(app => (
                <tr key={app.id}>
                  <td style={{padding: '10px 12px'}}>{app.dateApplied}</td>
                  <td style={{padding: '10px 12px'}}>{app.leavingDate}</td>
                  <td style={{padding: '10px 12px'}}>{app.reason}</td>
                  <td style={{padding: '10px 12px'}}>
                    <span style={{
                      background: statusColor(app.status),
                      color: '#fff',
                      borderRadius: 6,
                      padding: '4px 12px',
                      fontWeight: 600,
                      fontSize: '0.98rem',
                    }}>{app.status}</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default LeavingHostel; 