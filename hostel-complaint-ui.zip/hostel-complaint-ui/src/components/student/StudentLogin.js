import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import CommonHeader from '../CommonHeader';
import './StudentLogin.css';
import { useUser } from '../../UserContext';
import { getStudentByEmail } from './usersData';

const StudentLogin = () => {
  const navigate = useNavigate();
  const { updateUser } = useUser();

  const handleSubmit = (e) => {
    e.preventDefault();
    const name = e.target[0].value;
    const email = e.target[1].value;
    const password = e.target[2].value;
    const student = getStudentByEmail(email);
    if (!student) {
      alert('No student found with this email.');
      return;
    }
    if (student.password !== password) {
      alert('Incorrect password.');
      return;
    }
    updateUser({ name, email: student.email, role: 'Student' });
    alert('Login successful!');
    navigate('/dashboard');
  };

  return (
    <div className="login-container">
      <CommonHeader 
        title="Student Login"
        userRole="student"
        showMenu={false}
        showBackButton={true}
      />
      <div className="login-content">
        <form className="login-form" onSubmit={handleSubmit}>
          <h2 className="login-title">Student Login</h2>
          <input type="text" placeholder="Name" className="login-input" required />
          <input type="email" placeholder="Email" className="login-input" required />
          <input type="password" placeholder="Password" className="login-input" required />
          <button type="submit" className="login-btn">Login</button>
          <p className="login-link"><Link to="/student/change-password">Change Password</Link> | <Link to="/student/change-password">Forgot Password?</Link></p>
        </form>
      </div>
    </div>
  );
};

export default StudentLogin; 