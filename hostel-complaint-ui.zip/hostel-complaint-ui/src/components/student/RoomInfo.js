import React, { useEffect, useState } from 'react';
import CommonHeader from '../CommonHeader';
import { useUser } from '../../UserContext';

const getRooms = () => JSON.parse(localStorage.getItem('rooms') || '{}');

const RoomInfo = () => {
  const { user } = useUser();
  const [foundRoom, setFoundRoom] = useState(null);
  const [foundInfo, setFoundInfo] = useState(null);

  useEffect(() => {
    const rooms = getRooms();
    let room = null;
    let info = null;
    if (user && user.name) {
      for (const [r, i] of Object.entries(rooms)) {
        if (i.roommates.some(rm => rm.toLowerCase() === user.name.toLowerCase())) {
          room = r;
          info = i;
          break;
        }
      }
    }
    setFoundRoom(room);
    setFoundInfo(info);
  }, [user]);

  return (
    <div className="complaint-container">
      <CommonHeader title="Room Information" userRole="student" showMenu={true} showBackButton={true} />
      <div className="complaint-content-wrapper">
        <div className="complaint-content" style={{maxWidth: 520}}>
          <h2 style={{textAlign: 'center', color: '#185a9d', marginBottom: 18}}>Room Details</h2>
          {foundRoom ? (
            <table style={{width: '100%', borderCollapse: 'collapse', marginBottom: 18, background: '#f8fafd', borderRadius: 10, overflow: 'hidden', boxShadow: '0 2px 8px rgba(67,206,162,0.08)'}}>
              <tbody>
                <tr style={{background: '#43cea2', color: '#fff'}}>
                  <th style={{padding: '10px 12px', textAlign: 'left'}}>Room Number</th>
                  <td style={{padding: '10px 12px'}}>{foundRoom}</td>
                </tr>
                <tr>
                  <th style={{padding: '10px 12px', textAlign: 'left'}}>Floor</th>
                  <td style={{padding: '10px 12px'}}>{foundInfo.floor}</td>
                </tr>
                <tr>
                  <th style={{padding: '10px 12px', textAlign: 'left', verticalAlign: 'top'}}>Roommates</th>
                  <td style={{padding: '10px 12px'}}>
                    <ul style={{margin: 0, paddingLeft: 18}}>
                      {foundInfo.roommates.map((r, i) => <li key={i}>{r}</li>)}
                    </ul>
                  </td>
                </tr>
              </tbody>
            </table>
          ) : (
            <div style={{color: '#e53e3e', textAlign: 'center'}}>No room information found for you.</div>
          )}
        </div>
      </div>
    </div>
  );
};

export default RoomInfo; 