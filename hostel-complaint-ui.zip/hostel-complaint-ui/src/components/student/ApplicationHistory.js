import React, { useState, useEffect } from 'react';
import CommonHeader from '../CommonHeader';
import { getLeaveApplications, getRoomChangeRequests } from './studentData';
import { useUser } from '../../UserContext';

const statusColor = status => {
  if (status === 'Approved') return '#1ca97a';
  if (status === 'Rejected') return '#e53e3e';
  return '#185a9d';
};

const ApplicationHistory = () => {
  const [tab, setTab] = useState('leave');
  const [leaves, setLeaves] = useState([]);
  const [roomChanges, setRoomChanges] = useState([]);
  const { user } = useUser();

  useEffect(() => {
    if (user && user.name) {
      setLeaves(getLeaveApplications(user.name));
      setRoomChanges(getRoomChangeRequests(user.name));
    }
  }, [user]);

  return (
    <div className="complaint-container">
      <CommonHeader title="Application History" userRole="student" showMenu={true} showBackButton={true} />
      <div className="complaint-content-wrapper">
        <div className="complaint-content" style={{maxWidth: 800}}>
          <h2 style={{textAlign: 'center', color: '#185a9d', marginBottom: 18}}>My Applications</h2>
          <div style={{display: 'flex', justifyContent: 'center', marginBottom: 24, gap: 16}}>
            <button onClick={() => setTab('leave')} style={{padding: '8px 22px', borderRadius: 8, border: 'none', background: tab === 'leave' ? '#43cea2' : '#f8fafd', color: tab === 'leave' ? '#fff' : '#185a9d', fontWeight: 600, fontSize: '1rem', cursor: 'pointer', boxShadow: tab === 'leave' ? '0 2px 8px rgba(67,206,162,0.10)' : 'none'}}>Leave Applications</button>
            <button onClick={() => setTab('room')} style={{padding: '8px 22px', borderRadius: 8, border: 'none', background: tab === 'room' ? '#43cea2' : '#f8fafd', color: tab === 'room' ? '#fff' : '#185a9d', fontWeight: 600, fontSize: '1rem', cursor: 'pointer', boxShadow: tab === 'room' ? '0 2px 8px rgba(67,206,162,0.10)' : 'none'}}>Room Change Requests</button>
          </div>
          {tab === 'leave' ? (
            <table style={{width: '100%', borderCollapse: 'collapse', background: '#f8fafd', borderRadius: 10, overflow: 'hidden', boxShadow: '0 2px 8px rgba(67,206,162,0.08)'}}>
              <thead>
                <tr style={{background: '#43cea2', color: '#fff'}}>
                  <th style={{padding: '10px 12px'}}>From</th>
                  <th style={{padding: '10px 12px'}}>To</th>
                  <th style={{padding: '10px 12px'}}>Reason</th>
                  <th style={{padding: '10px 12px'}}>Status</th>
                </tr>
              </thead>
              <tbody>
                {leaves.length === 0 && (
                  <tr><td colSpan={4} style={{textAlign: 'center', padding: 18, color: '#888'}}>No leave applications yet.</td></tr>
                )}
                {leaves.map(l => (
                  <tr key={l.id}>
                    <td style={{padding: '10px 12px'}}>{l.from}</td>
                    <td style={{padding: '10px 12px'}}>{l.to}</td>
                    <td style={{padding: '10px 12px'}}>{l.reason}</td>
                    <td style={{padding: '10px 12px'}}>
                      <span style={{
                        background: statusColor(l.status),
                        color: '#fff',
                        borderRadius: 6,
                        padding: '4px 12px',
                        fontWeight: 600,
                        fontSize: '0.98rem',
                      }}>{l.status}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <table style={{width: '100%', borderCollapse: 'collapse', background: '#f8fafd', borderRadius: 10, overflow: 'hidden', boxShadow: '0 2px 8px rgba(67,206,162,0.08)'}}>
              <thead>
                <tr style={{background: '#43cea2', color: '#fff'}}>
                  <th style={{padding: '10px 12px'}}>Date</th>
                  <th style={{padding: '10px 12px'}}>Preferred Room</th>
                  <th style={{padding: '10px 12px'}}>Reason</th>
                  <th style={{padding: '10px 12px'}}>Status</th>
                </tr>
              </thead>
              <tbody>
                {roomChanges.length === 0 && (
                  <tr><td colSpan={4} style={{textAlign: 'center', padding: 18, color: '#888'}}>No room change requests yet.</td></tr>
                )}
                {roomChanges.map(r => (
                  <tr key={r.id}>
                    <td style={{padding: '10px 12px'}}>{r.date}</td>
                    <td style={{padding: '10px 12px'}}>{r.preferred}</td>
                    <td style={{padding: '10px 12px'}}>{r.reason}</td>
                    <td style={{padding: '10px 12px'}}>
                      <span style={{
                        background: statusColor(r.status),
                        color: '#fff',
                        borderRadius: 6,
                        padding: '4px 12px',
                        fontWeight: 600,
                        fontSize: '0.98rem',
                      }}>{r.status}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
};

export default ApplicationHistory; 