import React from 'react';
import CommonHeader from '../CommonHeader';
import { FaCheckCircle } from 'react-icons/fa';

const rules = [
  'Maintain silence after 10 PM.',
  'No outside guests allowed after 8 PM.',
  'Keep your room and common areas clean.',
  'No smoking or alcohol inside hostel premises.',
  'Respect hostel staff and fellow residents.',
  'Report any issues to the warden promptly.',
  'Use water and electricity responsibly.',
  'Follow all safety and fire regulations.',
];

const HostelRules = () => (
  <div className="complaint-container">
    <CommonHeader title="Hostel Rules & Regulations" userRole="student" showMenu={true} showBackButton={true} />
    <div className="complaint-content-wrapper">
      <div className="complaint-content" style={{maxWidth: 600}}>
        <h2 style={{textAlign: 'center', color: '#185a9d', marginBottom: 18}}>Hostel Rules</h2>
        <ul style={{padding: 0, margin: 0}}>
          {rules.map((rule, i) => (
            <li key={i} style={{
              display: 'flex', alignItems: 'center', background: '#f8fafd', borderRadius: 10, marginBottom: 14, padding: '14px 18px', boxShadow: '0 2px 8px rgba(67,206,162,0.07)'}}>
              <FaCheckCircle style={{color: '#43cea2', marginRight: 14, fontSize: 20}} />
              <span style={{fontSize: '1.08rem', color: '#185a9d', fontWeight: 500}}>{rule}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  </div>
);

export default HostelRules; 