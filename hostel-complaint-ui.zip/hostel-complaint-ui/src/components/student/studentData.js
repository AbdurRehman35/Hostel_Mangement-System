// Utility functions for student leave and room change applications

// Key names for localStorage
const LEAVE_KEY = 'leaveApplications';
const ROOM_CHANGE_KEY = 'roomChangeRequests';

// Get all leave applications (optionally filtered by student name/email)
export function getLeaveApplications(student) {
  const all = JSON.parse(localStorage.getItem(LEAVE_KEY) || '[]');
  if (!student) return all;
  return all.filter(app => app.student === student);
}

// Add a new leave application
export function addLeaveApplication(application) {
  const all = JSON.parse(localStorage.getItem(LEAVE_KEY) || '[]');
  all.unshift(application);
  localStorage.setItem(LEAVE_KEY, JSON.stringify(all));
}

// Get all room change requests (optionally filtered by student name/email)
export function getRoomChangeRequests(student) {
  const all = JSON.parse(localStorage.getItem(ROOM_CHANGE_KEY) || '[]');
  if (!student) return all;
  return all.filter(app => app.student === student);
}

// Add a new room change request
export function addRoomChangeRequest(request) {
  const all = JSON.parse(localStorage.getItem(ROOM_CHANGE_KEY) || '[]');
  all.unshift(request);
  localStorage.setItem(ROOM_CHANGE_KEY, JSON.stringify(all));
} 