import React from 'react';
import { useNavigate } from 'react-router-dom';
import CommonHeader from '../CommonHeader';
import './AdminPanel.css';
import AdminDashboardAnalytics from './AdminDashboardAnalytics';

const AdminPanel = () => {
  const navigate = useNavigate();
  return (
    <div className="admin-panel-container">
      <CommonHeader 
        title="Admin Dashboard" 
        userRole="admin"
        showMenu={true}
        showBackButton={false}
      />
      <main className="admin-panel-main">
        <div className="admin-panel-content">
          <AdminDashboardAnalytics />
          <h1 className="admin-panel-title">Admin Services</h1>
          <div className="admin-panel-stats">
            <div className="admin-panel-card" onClick={() => navigate('/admin/students')}>
              <div className="admin-card-icon">👥</div>
              <div className="admin-card-label">Student Management</div>
              <div className="admin-card-value">View, add, or remove students</div>
            </div>
            <div className="admin-panel-card" onClick={() => navigate('/admin/wardens')}>
              <div className="admin-card-icon">🧑‍🏫</div>
              <div className="admin-card-label">Warden Management</div>
              <div className="admin-card-value">View, add, or remove wardens</div>
            </div>
            <div className="admin-panel-card" onClick={() => navigate('/admin/all-students-list')}>
              <div className="admin-card-icon">📋</div>
              <div className="admin-card-label">All Students List</div>
              <div className="admin-card-value">See all students with date/time</div>
            </div>
            <div className="admin-panel-card" onClick={() => navigate('/admin/all-wardens-list')}>
              <div className="admin-card-icon">📋</div>
              <div className="admin-card-label">All Wardens List</div>
              <div className="admin-card-value">See all wardens with block and date/time</div>
            </div>
            <div className="admin-panel-card" onClick={() => navigate('/admin/leaving-removals')}>
              <div className="admin-card-icon">🚪</div>
              <div className="admin-card-label">Leaving Hostel Removals</div>
              <div className="admin-card-value">Remove students after approval</div>
            </div>
            <div className="admin-panel-card" onClick={() => navigate('/admin/send-message')}>
              <div className="admin-card-icon">✉️</div>
              <div className="admin-card-label">Send Message</div>
              <div className="admin-card-value">Send message to all or specific students</div>
            </div>
            <div className="admin-panel-card" onClick={() => navigate('/admin/send-message-wardens')}>
              <div className="admin-card-icon">✉️</div>
              <div className="admin-card-label">Send Message to Wardens</div>
              <div className="admin-card-value">Send message to all or specific wardens</div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default AdminPanel; 