import React, { useEffect, useState } from 'react';
import CommonHeader from '../CommonHeader';
import { getAllWardens, addWarden, removeWarden } from '../student/usersData';

const AdminWardenManagement = () => {
  const [wardens, setWardens] = useState([]);
  const [form, setForm] = useState({ name: '', email: '', password: '', block: '' });
  const [success, setSuccess] = useState(false);

  useEffect(() => {
    setWardens(getAllWardens());
  }, []);

  const handleChange = e => {
    const { name, value } = e.target;
    let newForm = { ...form, [name]: value };
    if (name === 'name') {
      // Generate email
      const [first, ...rest] = (newForm.name || '').trim().toLowerCase().split(' ');
      const last = rest.join('.') || '';
      if (first) {
        newForm.email = `${first}${last ? '.' + last : ''}.warden@hostel.edu`;
      } else {
        newForm.email = '';
      }
    }
    setForm(newForm);
  };

  const handleAdd = e => {
    e.preventDefault();
    if (!form.name || !form.email || !form.password) return;
    addWarden(form);
    setWardens(getAllWardens());
    setForm({ name: '', email: '', password: '' });
    setSuccess(true);
    setTimeout(() => setSuccess(false), 2000);
  };

  const handleRemove = email => {
    removeWarden(email);
    setWardens(getAllWardens());
  };

  return (
    <div className="complaint-container">
      <CommonHeader title="Warden Management" userRole="admin" showMenu={true} showBackButton={true} />
      <div className="complaint-content-wrapper">
        <div className="complaint-content" style={{maxWidth: 700}}>
          <h2 style={{textAlign: 'center', color: '#185a9d', marginBottom: 18}}>All Wardens</h2>
          {success && <div className="complaint-success">Warden added!</div>}
          <form className="complaint-form" onSubmit={handleAdd} style={{marginBottom: 32}}>
            <div className="form-group">
              <label className="form-label">Name *</label>
              <input type="text" className="form-input" name="name" value={form.name} onChange={handleChange} required />
            </div>
            <div className="form-group">
              <label className="form-label">Block *</label>
              <input type="text" className="form-input" name="block" value={form.block} onChange={handleChange} required />
            </div>
            <div className="form-group">
              <label className="form-label">Email</label>
              <input type="email" className="form-input" name="email" value={form.email} disabled />
            </div>
            <div className="form-group">
              <label className="form-label">Password *</label>
              <input type="password" className="form-input" name="password" value={form.password} onChange={handleChange} required />
            </div>
            <button type="submit" className="submit-btn">Add Warden</button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default AdminWardenManagement; 