import React, { useEffect, useState } from 'react';
import { getAllStudents, getAllWardens } from '../student/usersData';
import { getComplaints } from '../complaintsData';
import './AdminPanel.css';

const AdminDashboardAnalytics = () => {
  const [totalStudents, setTotalStudents] = useState(0);
  const [totalWardens, setTotalWardens] = useState(0);
  const [complaintsThisMonth, setComplaintsThisMonth] = useState(0);
  const [pendingApprovals, setPendingApprovals] = useState(0);

  useEffect(() => {
    // Students & Wardens
    setTotalStudents(getAllStudents().length);
    setTotalWardens(getAllWardens().length);

    // Complaints this month
    const complaints = getComplaints();
    const now = new Date();
    const month = now.getMonth();
    const year = now.getFullYear();
    const thisMonthComplaints = complaints.filter(c => {
      const d = new Date(c.date);
      return d.getMonth() === month && d.getFullYear() === year;
    });
    setComplaintsThisMonth(thisMonthComplaints.length);

    // Pending approvals (mock: count complaints with status 'Pending')
    setPendingApprovals(complaints.filter(c => c.status === 'Pending').length);
  }, []);

  return (
    <div className="admin-analytics-container">
      <div className="admin-analytics-card">
        <div className="admin-analytics-label">Total Students</div>
        <div className="admin-analytics-value">{totalStudents}</div>
      </div>
      <div className="admin-analytics-card">
        <div className="admin-analytics-label">Total Wardens</div>
        <div className="admin-analytics-value">{totalWardens}</div>
      </div>
      <div className="admin-analytics-card">
        <div className="admin-analytics-label">Complaints This Month</div>
        <div className="admin-analytics-value">{complaintsThisMonth}</div>
      </div>
      <div className="admin-analytics-card">
        <div className="admin-analytics-label">Pending Approvals</div>
        <div className="admin-analytics-value">{pendingApprovals}</div>
      </div>
    </div>
  );
};

export default AdminDashboardAnalytics; 