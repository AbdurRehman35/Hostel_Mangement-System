import React, { useEffect, useState } from 'react';
import CommonHeader from '../CommonHeader';
import { getAllStudents, removeStudent } from '../student/usersData';

const LEAVING_KEY = 'leavingHostelApplications';

function getApprovedLeavingApplications() {
  const all = JSON.parse(localStorage.getItem(LEAVING_KEY) || '[]');
  return all.filter(app => app.status === 'Approved');
}

const AdminLeavingRemovals = () => {
  const [apps, setApps] = useState([]);
  const [students, setStudents] = useState([]);

  useEffect(() => {
    setApps(getApprovedLeavingApplications());
    setStudents(getAllStudents());
  }, []);

  const handleRemove = email => {
    removeStudent(email);
    setStudents(getAllStudents());
    // Optionally remove from leaving applications as well
    setApps(getApprovedLeavingApplications());
  };

  const getStudent = email => students.find(s => s.email === email);

  return (
    <div className="complaint-container">
      <CommonHeader title="Leaving Hostel Removals" userRole="admin" showMenu={true} showBackButton={true} />
      <div className="complaint-content-wrapper">
        <div className="complaint-content" style={{maxWidth: 800}}>
          <h2 style={{textAlign: 'center', color: '#185a9d', marginBottom: 18}}>Students Approved for Leaving Hostel</h2>
          <table style={{width: '100%', borderCollapse: 'collapse', background: '#f8fafd', borderRadius: 10, overflow: 'hidden', boxShadow: '0 2px 8px rgba(67,206,162,0.08)'}}>
            <thead>
              <tr style={{background: '#43cea2', color: '#fff'}}>
                <th style={{padding: '10px 12px'}}>Name</th>
                <th style={{padding: '10px 12px'}}>Email</th>
                <th style={{padding: '10px 12px'}}>Leaving Date</th>
                <th style={{padding: '10px 12px'}}>Action</th>
              </tr>
            </thead>
            <tbody>
              {apps.length === 0 && (
                <tr><td colSpan={4} style={{textAlign: 'center', padding: 18, color: '#888'}}>No students approved for leaving hostel.</td></tr>
              )}
              {apps.map(app => {
                const student = getStudent(app.studentEmail || app.student);
                return (
                  <tr key={app.id}>
                    <td style={{padding: '10px 12px'}}>{student ? student.name : app.student}</td>
                    <td style={{padding: '10px 12px'}}>{student ? student.email : (app.studentEmail || '-')}</td>
                    <td style={{padding: '10px 12px'}}>{app.leavingDate}</td>
                    <td style={{padding: '10px 12px'}}>
                      <button onClick={() => handleRemove(student ? student.email : app.studentEmail)} style={{background: '#e53e3e', color: '#fff', border: 'none', borderRadius: 6, padding: '6px 14px', fontWeight: 600, cursor: 'pointer'}}>Remove</button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default AdminLeavingRemovals; 