import React, { useEffect, useState } from 'react';
import CommonHeader from '../CommonHeader';
import { getAllWardens, removeWarden, addNotification, updateWardenPassword } from '../student/usersData';
import { useLocation } from 'react-router-dom';

const AllWardensList = () => {
  const [wardens, setWardens] = useState([]);
  const [search, setSearch] = useState('');
  const [selected, setSelected] = useState([]);
  const [profile, setProfile] = useState(null);
  const [filterBlock, setFilterBlock] = useState('');
  const [filterDateFrom, setFilterDateFrom] = useState('');
  const [filterDateTo, setFilterDateTo] = useState('');
  const [sortBy, setSortBy] = useState('addedAt');
  const [sortDir, setSortDir] = useState('desc');
  const [notifyModal, setNotifyModal] = useState(false);
  const [notifyMsg, setNotifyMsg] = useState('');
  const [notifyTarget, setNotifyTarget] = useState(''); // 'all' or 'selected'
  const [resetPwdModal, setResetPwdModal] = useState(false);
  const [resetPwdValue, setResetPwdValue] = useState('');
  const location = useLocation();

  useEffect(() => {
    setWardens(getAllWardens());
  }, [location]);

  const handleRemove = (email) => {
    if (window.confirm('Are you sure you want to remove this warden?')) {
      removeWarden(email);
      setWardens(getAllWardens());
    }
  };

  // Unique blocks for dropdown
  const uniqueBlocks = Array.from(new Set(wardens.map(w => w.block).filter(Boolean)));

  let filteredWardens = wardens.filter(w => {
    const q = search.toLowerCase();
    let match = (
      w.name?.toLowerCase().includes(q) ||
      w.email?.toLowerCase().includes(q) ||
      (w.block || '').toLowerCase().includes(q)
    );
    if (filterBlock && w.block !== filterBlock) match = false;
    if (filterDateFrom && (!w.addedAt || new Date(w.addedAt) < new Date(filterDateFrom))) match = false;
    if (filterDateTo && (!w.addedAt || new Date(w.addedAt) > new Date(filterDateTo))) match = false;
    return match;
  });
  // Sorting
  filteredWardens = filteredWardens.sort((a, b) => {
    let vA = a[sortBy] || '';
    let vB = b[sortBy] || '';
    if (sortBy === 'addedAt') {
      vA = vA ? new Date(vA) : 0;
      vB = vB ? new Date(vB) : 0;
    } else {
      vA = vA.toString().toLowerCase();
      vB = vB.toString().toLowerCase();
    }
    if (vA < vB) return sortDir === 'asc' ? -1 : 1;
    if (vA > vB) return sortDir === 'asc' ? 1 : -1;
    return 0;
  });
  const handleSort = (col) => {
    if (sortBy === col) setSortDir(sortDir === 'asc' ? 'desc' : 'asc');
    else { setSortBy(col); setSortDir('asc'); }
  };

  const allSelected = filteredWardens.length > 0 && selected.length === filteredWardens.length;
  const toggleSelectAll = () => {
    if (allSelected) setSelected([]);
    else setSelected(filteredWardens.map(w => w.email));
  };
  const toggleSelect = (email) => {
    setSelected(selected.includes(email) ? selected.filter(e => e !== email) : [...selected, email]);
  };
  const handleBulkRemove = () => {
    if (window.confirm(`Remove ${selected.length} wardens?`)) {
      selected.forEach(email => removeWarden(email));
      setWardens(getAllWardens());
      setSelected([]);
    }
  };
  const handleBulkNotify = () => {
    setNotifyTarget('selected');
    setNotifyModal(true);
  };
  const handleBroadcast = () => {
    setNotifyTarget('all');
    setNotifyModal(true);
  };
  const sendNotification = () => {
    if (!notifyMsg.trim()) return;
    const targets = notifyTarget === 'all' ? wardens.map(w => w.email) : selected;
    targets.forEach(email => {
      addNotification(email, { id: Date.now(), message: notifyMsg, date: new Date().toISOString().slice(0, 10) });
    });
    alert('Notification sent!');
    setNotifyModal(false);
    setNotifyMsg('');
    setSelected([]);
  };

  return (
    <div className="complaint-container">
      <CommonHeader title="All Wardens List" userRole="admin" showMenu={true} showBackButton={true} />
      <div className="complaint-content-wrapper">
        <div className="complaint-content" style={{maxWidth: 900}}>
          <h2 style={{textAlign: 'center', color: '#185a9d', marginBottom: 18}}>All Wardens (with Block & Date/Time Added)</h2>
          <input
            type="text"
            placeholder="Search by name, email, or block..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            style={{marginBottom: 18, padding: '8px 14px', borderRadius: 6, border: '1.5px solid #43cea2', width: '100%', maxWidth: 350, fontSize: 16}}
          />
          <div style={{display: 'flex', gap: 12, marginBottom: 18, flexWrap: 'wrap'}}>
            <select value={filterBlock} onChange={e => setFilterBlock(e.target.value)} style={{padding: '7px 12px', borderRadius: 6, border: '1.5px solid #43cea2'}}>
              <option value=''>All Blocks</option>
              {uniqueBlocks.map(b => <option key={b} value={b}>{b}</option>)}
            </select>
            <input type="date" value={filterDateFrom} onChange={e => setFilterDateFrom(e.target.value)} style={{padding: '7px 12px', borderRadius: 6, border: '1.5px solid #43cea2'}} placeholder="From" />
            <input type="date" value={filterDateTo} onChange={e => setFilterDateTo(e.target.value)} style={{padding: '7px 12px', borderRadius: 6, border: '1.5px solid #43cea2'}} placeholder="To" />
            <button onClick={() => { setFilterBlock(''); setFilterDateFrom(''); setFilterDateTo(''); }} style={{padding: '7px 12px', borderRadius: 6, border: '1.5px solid #e53e3e', background: '#fff', color: '#e53e3e', fontWeight: 600, cursor: 'pointer'}}>Clear Filters</button>
          </div>
          <button onClick={handleBroadcast} style={{marginBottom: 16, background: '#185a9d', color: '#fff', border: 'none', borderRadius: 6, padding: '8px 18px', fontWeight: 600, cursor: 'pointer'}}>Broadcast Notification to All</button>
          {selected.length > 0 && (
            <div style={{marginBottom: 16, background: '#f8fafd', border: '1.5px solid #43cea2', borderRadius: 8, padding: '10px 18px', display: 'flex', alignItems: 'center', gap: 16}}>
              <span style={{fontWeight: 600}}>{selected.length} selected</span>
              <button onClick={handleBulkRemove} style={{background: '#e53e3e', color: '#fff', border: 'none', borderRadius: 6, padding: '6px 14px', fontWeight: 600, cursor: 'pointer'}}>Remove</button>
              <button onClick={handleBulkNotify} style={{background: '#43cea2', color: '#fff', border: 'none', borderRadius: 6, padding: '6px 14px', fontWeight: 600, cursor: 'pointer'}}>Send Notification</button>
            </div>
          )}
          <table style={{width: '100%', borderCollapse: 'collapse', background: '#f8fafd', borderRadius: 10, overflow: 'hidden', boxShadow: '0 2px 8px rgba(67,206,162,0.08)'}}>
            <thead>
              <tr style={{background: '#43cea2', color: '#fff'}}>
                <th style={{padding: '10px 12px'}}>
                  <input type="checkbox" checked={allSelected} onChange={toggleSelectAll} />
                </th>
                <th style={{padding: '10px 12px', cursor: 'pointer'}} onClick={() => handleSort('name')}>Name {sortBy==='name' ? (sortDir==='asc'?'▲':'▼') : ''}</th>
                <th style={{padding: '10px 12px', cursor: 'pointer'}} onClick={() => handleSort('email')}>Email {sortBy==='email' ? (sortDir==='asc'?'▲':'▼') : ''}</th>
                <th style={{padding: '10px 12px', cursor: 'pointer'}} onClick={() => handleSort('block')}>Block {sortBy==='block' ? (sortDir==='asc'?'▲':'▼') : ''}</th>
                <th style={{padding: '10px 12px', cursor: 'pointer'}} onClick={() => handleSort('addedAt')}>Date/Time Added {sortBy==='addedAt' ? (sortDir==='asc'?'▲':'▼') : ''}</th>
                <th style={{padding: '10px 12px'}}>Action</th>
              </tr>
            </thead>
            <tbody>
              {filteredWardens.length === 0 && (
                <tr><td colSpan={5} style={{textAlign: 'center', padding: 18, color: '#888'}}>No wardens found.</td></tr>
              )}
              {filteredWardens.map(w => (
                <tr key={w.email} style={{cursor: 'pointer'}} onClick={e => { if (e.target.tagName !== 'BUTTON' && e.target.tagName !== 'INPUT') setProfile(w); }}>
                  <td style={{padding: '10px 12px'}}>
                    <input type="checkbox" checked={selected.includes(w.email)} onChange={() => toggleSelect(w.email)} />
                  </td>
                  <td style={{padding: '10px 12px'}}>{w.name}</td>
                  <td style={{padding: '10px 12px'}}>{w.email}</td>
                  <td style={{padding: '10px 12px'}}>{w.block || '-'}</td>
                  <td style={{padding: '10px 12px'}}>{w.addedAt ? new Date(w.addedAt).toLocaleString() : '-'}</td>
                  <td style={{padding: '10px 12px'}}>
                    <button onClick={e => { e.stopPropagation(); handleRemove(w.email); }} style={{background: '#e53e3e', color: '#fff', border: 'none', borderRadius: 6, padding: '6px 14px', fontWeight: 600, cursor: 'pointer'}}>Remove</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      {profile && (
        <div style={{position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', background: 'rgba(0,0,0,0.25)', zIndex: 3000, display: 'flex', alignItems: 'center', justifyContent: 'center'}} onClick={() => setProfile(null)}>
          <div style={{background: '#fff', borderRadius: 16, boxShadow: '0 8px 32px rgba(67,206,162,0.18)', padding: '2.2rem 2.5rem 1.5rem 2.5rem', minWidth: 340, maxWidth: '90vw', minHeight: 220, position: 'relative'}} onClick={e => e.stopPropagation()}>
            <button onClick={() => setProfile(null)} style={{position: 'absolute', top: 18, right: 18, background: 'none', border: 'none', fontSize: 22, color: '#185a9d', cursor: 'pointer'}}>×</button>
            <h2 style={{margin: 0, color: '#185a9d', fontWeight: 700, fontSize: 22, marginBottom: 18}}>Warden Profile</h2>
            <div style={{marginBottom: 10}}><b>Name:</b> {profile.name}</div>
            <div style={{marginBottom: 10}}><b>Email:</b> {profile.email}</div>
            <div style={{marginBottom: 10}}><b>Block:</b> {profile.block}</div>
            <div style={{marginBottom: 10}}><b>Date/Time Added:</b> {profile.addedAt ? new Date(profile.addedAt).toLocaleString() : '-'}</div>
            <button onClick={() => { setResetPwdModal(true); setResetPwdValue(''); }} style={{marginTop: 18, background: '#185a9d', color: '#fff', border: 'none', borderRadius: 8, padding: '10px 24px', fontWeight: 600, fontSize: 16, cursor: 'pointer'}}>Reset Password</button>
          </div>
        </div>
      )}
      {resetPwdModal && profile && (
        <div style={{position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', background: 'rgba(0,0,0,0.25)', zIndex: 4000, display: 'flex', alignItems: 'center', justifyContent: 'center'}} onClick={() => setResetPwdModal(false)}>
          <div style={{background: '#fff', borderRadius: 16, boxShadow: '0 8px 32px rgba(67,206,162,0.18)', padding: '2.2rem 2.5rem 1.5rem 2.5rem', minWidth: 340, maxWidth: '90vw', minHeight: 120, position: 'relative'}} onClick={e => e.stopPropagation()}>
            <button onClick={() => setResetPwdModal(false)} style={{position: 'absolute', top: 18, right: 18, background: 'none', border: 'none', fontSize: 22, color: '#185a9d', cursor: 'pointer'}}>×</button>
            <h2 style={{margin: 0, color: '#185a9d', fontWeight: 700, fontSize: 20, marginBottom: 18}}>Reset Password</h2>
            <input type="password" value={resetPwdValue} onChange={e => setResetPwdValue(e.target.value)} placeholder="Enter new password..." style={{width: '100%', borderRadius: 8, border: '1.5px solid #43cea2', padding: 10, fontSize: 16, marginBottom: 18}} />
            <button onClick={() => { if (resetPwdValue.trim()) { updateWardenPassword(profile.email, resetPwdValue); alert('Password reset!'); setResetPwdModal(false); setProfile(null); }}} style={{background: '#43cea2', color: '#fff', border: 'none', borderRadius: 8, padding: '10px 24px', fontWeight: 600, fontSize: 16, cursor: 'pointer'}}>Reset</button>
          </div>
        </div>
      )}
      {notifyModal && (
        <div style={{position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', background: 'rgba(0,0,0,0.25)', zIndex: 4000, display: 'flex', alignItems: 'center', justifyContent: 'center'}} onClick={() => setNotifyModal(false)}>
          <div style={{background: '#fff', borderRadius: 16, boxShadow: '0 8px 32px rgba(67,206,162,0.18)', padding: '2.2rem 2.5rem 1.5rem 2.5rem', minWidth: 340, maxWidth: '90vw', minHeight: 120, position: 'relative'}} onClick={e => e.stopPropagation()}>
            <button onClick={() => setNotifyModal(false)} style={{position: 'absolute', top: 18, right: 18, background: 'none', border: 'none', fontSize: 22, color: '#185a9d', cursor: 'pointer'}}>×</button>
            <h2 style={{margin: 0, color: '#185a9d', fontWeight: 700, fontSize: 20, marginBottom: 18}}>Send Notification {notifyTarget==='all' ? 'to All Wardens' : `to ${selected.length} Selected`}</h2>
            <textarea value={notifyMsg} onChange={e => setNotifyMsg(e.target.value)} placeholder="Enter your message..." style={{width: '100%', minHeight: 70, borderRadius: 8, border: '1.5px solid #43cea2', padding: 10, fontSize: 16, marginBottom: 18}} />
            <button onClick={sendNotification} style={{background: '#43cea2', color: '#fff', border: 'none', borderRadius: 8, padding: '10px 24px', fontWeight: 600, fontSize: 16, cursor: 'pointer'}}>Send</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default AllWardensList; 