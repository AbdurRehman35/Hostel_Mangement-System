import React, { useEffect, useState } from 'react';
import CommonHeader from '../CommonHeader';
import { getAllStudents, addStudent, removeStudent, getAllWardens, addNotification } from '../student/usersData';

const AdminStudentManagement = () => {
  const [students, setStudents] = useState([]);
  const [form, setForm] = useState({ name: '', email: '', roomNumber: '', floor: '', block: '', password: '' });
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');
  const [wardens, setWardens] = useState([]);

  useEffect(() => {
    setStudents(getAllStudents());
    setWardens(getAllWardens());
  }, []);

  const handleChange = e => {
    const { name, value } = e.target;
    let newForm = { ...form, [name]: value };
    if (name === 'name' || name === 'roomNumber' || name === 'floor' || name === 'block') {
      // Generate email
      const [first, ...rest] = (newForm.name || '').trim().toLowerCase().split(' ');
      const last = rest.join('.') || '';
      const room = newForm.roomNumber || '';
      const floor = newForm.floor || '';
      const block = newForm.block || '';
      if (first && room && floor && block) {
        newForm.email = `${first}${last ? '.' + last : ''}.r${room}.f${floor}.b${block}@hostel.edu`;
      } else {
        newForm.email = '';
      }
    }
    setForm(newForm);
  };

  const handleAdd = e => {
    e.preventDefault();
    setError('');
    if (!form.name || !form.email || !form.password) return;
    // Enforce max 5 students per room
    const studentsInRoom = getAllStudents().filter(s => s.roomNumber === form.roomNumber);
    if (studentsInRoom.length >= 5) {
      setError('Cannot add more than 5 students to one room.');
      return;
    }
    addStudent(form);
    setStudents(getAllStudents());
    // Notify the warden of the student's block
    const warden = wardens.find(w => w.block && w.block.toLowerCase() === (form.floor || '').toLowerCase());
    if (warden) {
      const message = `New student added to your block (${warden.block}):\nName: ${form.name}\nEmail: ${form.email}\nRoom: ${form.roomNumber}\nFloor: ${form.floor}`;
      addNotification(warden.email, { id: Date.now(), message, date: new Date().toISOString().slice(0, 10) });
    }
    setForm({ name: '', email: '', roomNumber: '', floor: '', block: '', password: '' });
    setSuccess(true);
    setTimeout(() => setSuccess(false), 2000);
  };

  const handleRemove = email => {
    removeStudent(email);
    setStudents(getAllStudents());
  };

  return (
    <div className="complaint-container">
      <CommonHeader title="Student Management" userRole="admin" showMenu={true} showBackButton={true} />
      <div className="complaint-content-wrapper">
        <div className="complaint-content" style={{maxWidth: 800}}>
          <h2 style={{textAlign: 'center', color: '#185a9d', marginBottom: 18}}>All Students</h2>
          {success && <div className="complaint-success">Student added!</div>}
          {error && <div className="complaint-error" style={{color:'#e53e3e', marginBottom:12, textAlign:'center'}}>{error}</div>}
          <form className="complaint-form" onSubmit={handleAdd} style={{marginBottom: 32}}>
            <div className="form-group">
              <label className="form-label">Name *</label>
              <input type="text" className="form-input" name="name" value={form.name} onChange={handleChange} required />
            </div>
            <div className="form-group">
              <label className="form-label">Room Number *</label>
              <input type="text" className="form-input" name="roomNumber" value={form.roomNumber} onChange={handleChange} required />
            </div>
            <div className="form-group">
              <label className="form-label">Floor *</label>
              <input type="text" className="form-input" name="floor" value={form.floor} onChange={handleChange} required />
            </div>
            <div className="form-group">
              <label className="form-label">Block *</label>
              <input type="number" className="form-input" name="block" value={form.block} onChange={handleChange} required min="1" step="1" />
            </div>
            <div className="form-group">
              <label className="form-label">Email</label>
              <input type="email" className="form-input" name="email" value={form.email} disabled />
            </div>
            <div className="form-group">
              <label className="form-label">Password *</label>
              <input type="password" className="form-input" name="password" value={form.password} onChange={handleChange} required />
            </div>
            <button type="submit" className="submit-btn">Add Student</button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default AdminStudentManagement; 