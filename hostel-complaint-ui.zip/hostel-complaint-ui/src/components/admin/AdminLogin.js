import React from 'react';
import CommonHeader from '../CommonHeader';
import './AdminLogin.css';
import { useUser } from '../../UserContext';
import { useNavigate } from 'react-router-dom';

const AdminLogin = () => {
  const { updateUser } = useUser();
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    const name = e.target[0].value;
    const username = e.target[1].value;
    // You may want to validate name/username here
    updateUser({ name, email: username, role: 'Admin' });
    alert('Login successful!');
    navigate('/admin/dashboard');
  };

  return (
    <div className="admin-login-container">
      <CommonHeader 
        title="Admin Login" 
        userRole="admin"
        showMenu={false}
        showBackButton={true}
      />
      <div className="admin-login-content">
        <div className="admin-login-card">
          <h2 className="admin-login-title">Admin Login</h2>
          <form className="admin-login-form" onSubmit={handleSubmit}>
            <input type="text" className="admin-login-input" placeholder="Name" required />
            <input type="text" className="admin-login-input" placeholder="Username" required />
            <input type="password" className="admin-login-input" placeholder="Password" required />
            <button type="submit" className="admin-login-btn">Login</button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default AdminLogin; 