import React from 'react';
import './SplashScreen.css';

const SplashScreen = () => {
  return (
    <div className="splash-container">
      <div style={{ textAlign: 'center', width: '100%' }}>
        <div style={{ fontSize: '4rem', marginBottom: '1.5rem' }}>🏨</div>
        <h1 className="splash-title">Hostel Room Complaint System</h1>
        <p className="splash-tagline">Easy. Fast. Transparent.</p>
      </div>
    </div>
  );
};

export default SplashScreen; 