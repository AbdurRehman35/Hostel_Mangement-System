import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { 
  FiHome, 
  FiFileText, 
  FiClock, 
  FiBell, 
  FiCalendar,
  FiUsers,
  FiSettings,
  FiLogOut,
  FiUser,
  FiArrowLeft
} from 'react-icons/fi';
import './Sidebar.css';
import { useUser } from '../UserContext';

const Sidebar = ({ isOpen, onClose, userRole }) => {
  const navigate = useNavigate();
  const location = useLocation();
  const { user } = useUser();

  const getMenuItems = () => {
    switch (userRole) {
      case 'student':
        return [
          { path: '/student/dashboard', label: 'Dashboard', icon: FiHome },
          { path: '/student/submit-complaint', label: 'Submit Complaint', icon: FiFileText },
          { path: '/student/complaint-history', label: 'Complaint History', icon: FiClock },
          { path: '/student/notifications', label: 'Notifications', icon: FiBell },
        ];
      case 'warden':
        return [
          { path: '/warden/dashboard', label: 'Dashboard', icon: FiHome },
          { path: '/warden/room-management', label: 'Room Management', icon: FiFileText },
          { path: '/warden/inspections', label: 'Inspections', icon: FiCalendar },
          { path: '/warden/leaving-hostel-approvals', label: 'Leaving Hostel Approvals', icon: FiClock },
          { path: '/warden/leave-approvals', label: 'Leave Applications', icon: FiClock },
          { path: '/warden/room-change-approvals', label: 'Room Change Requests', icon: FiClock },
          { path: '/warden/student-list', label: 'Student List', icon: FiUsers },
          { path: '/warden/fee-status', label: 'Fee Status', icon: FiSettings },
          { path: '/warden/notifications', label: 'Notifications', icon: FiBell },
          { path: '/warden/send-message', label: 'Send Message', icon: FiFileText },
        ];
      case 'admin':
        return [
          { path: '/admin/dashboard', label: 'Dashboard', icon: FiHome },
          { path: '/admin/users', label: 'User Management', icon: FiUsers },
          { path: '/admin/settings', label: 'Settings', icon: FiSettings },
          { path: '/admin/reports', label: 'Reports', icon: FiFileText },
        ];
      default:
        return [];
    }
  };

  const handleNavigation = (path) => {
    navigate(path);
    onClose();
  };

  const handleSignOut = () => {
    // Add sign out logic here
    navigate('/');
    onClose();
  };

  const handleBack = () => {
    navigate(-1);
    onClose();
  };

  const menuItems = getMenuItems();

  return (
    <>
      {/* Overlay */}
      {isOpen && <div className="sidebar-overlay" onClick={onClose} />}
      
      {/* Sidebar */}
      <div className={`sidebar ${isOpen ? 'sidebar-open' : ''}`}>
        <div className="sidebar-header">
          <button className="sidebar-back-btn" onClick={handleBack} title="Back">
            <FiArrowLeft />
          </button>
          <div className="sidebar-logo">
            <span className="logo-icon">🏨</span>
            <span className="logo-text">HostelComplaint</span>
          </div>
        </div>

        <nav className="sidebar-nav">
          <div className="nav-section">
            <h3 className="nav-section-title">Navigation</h3>
            {menuItems.map((item) => {
              const Icon = item.icon;
              const isActive = location.pathname === item.path;
              // Runtime check for icon type
              if (typeof Icon !== 'function') {
                throw new Error(`Sidebar menu item icon for path '${item.path}' is not a valid React component. Did you use <Icon /> instead of Icon?`);
              }
              return (
                <button
                  key={item.path}
                  className={`nav-item ${isActive ? 'nav-item-active' : ''}`}
                  onClick={() => handleNavigation(item.path)}
                >
                  <Icon className="nav-icon" />
                  <span className="nav-label">{item.label}</span>
                  {isActive && <div className="nav-indicator" />}
                </button>
              );
            })}
          </div>

          <div className="nav-section">
            <h3 className="nav-section-title">Account</h3>
            <button className="nav-item nav-item-signout" onClick={handleSignOut}>
              <FiLogOut className="nav-icon" />
              <span className="nav-label">Sign Out</span>
            </button>
          </div>
        </nav>

        <div className="sidebar-footer">
          {user && user.name && (
            <div className="user-info">
              <div className="user-avatar">
                <FiUser />
              </div>
              <div className="user-details">
                <span className="user-name">{user.name}</span>
                <span className="user-role">{userRole}</span>
              </div>
            </div>
          )}
          <div className="sidebar-copyright" style={{marginTop: 16, fontSize: '11px', color: 'rgba(255,255,255,0.5)', textAlign: 'center'}}>
            © {new Date().getFullYear()} HostelComplaint v1.0
          </div>
        </div>
      </div>
    </>
  );
};

export default Sidebar; 