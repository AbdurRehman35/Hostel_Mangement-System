import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import './CommonNav.css';

const CommonNav = ({ links }) => {
  const location = useLocation();
  return (
    <nav className="common-nav">
      {links.map(link => (
        <Link
          key={link.to}
          to={link.to}
          className={`nav-link${location.pathname === link.to ? ' active' : ''}`}
        >
          <span className="nav-icon">{link.icon}</span>
          <span className="nav-label">{link.label}</span>
        </Link>
      ))}
    </nav>
  );
};

export default CommonNav; 