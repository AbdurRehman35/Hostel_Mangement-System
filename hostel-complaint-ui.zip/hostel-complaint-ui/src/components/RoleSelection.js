import React from 'react';
import { useNavigate } from 'react-router-dom';
import './RoleSelection.css';

const roles = [
  {
    label: 'Student',
    icon: '🎓',
    to: '/student/register',
  },
  {
    label: 'Warden',
    icon: '🛡️',
    to: '/warden/login',
  },
  {
    label: 'Admin',
    icon: '⚙️',
    to: '/admin/login',
  },
];

const RoleSelection = () => {
  const navigate = useNavigate();
  return (
    <div className="role-selection-container">
      <div className="role-selection-card">
        <h2 className="role-selection-title">Who are you?</h2>
        <div className="role-buttons">
          {roles.map(role => (
            <button
              key={role.label}
              className="role-btn"
              onClick={() => navigate(role.to)}
            >
              <span className="role-icon">{role.icon}</span>
              <span className="role-label">{role.label}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default RoleSelection; 